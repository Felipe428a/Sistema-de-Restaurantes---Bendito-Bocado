package com.BenditoBocado.Restaurantes.controller;

import com.BenditoBocado.Restaurantes.dto.PedidoRequestDTO;
import com.BenditoBocado.Restaurantes.dto.PedidoResponseDTO;
import com.BenditoBocado.Restaurantes.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(
    name = "Consumidor",
    description = "Endpoints que actúan como cliente/consumidor de pedidos"
)
@RestController
@RequestMapping("/api/v1/consumer")
public class ConsumidorController {

    private final PedidoService pedidoService;

    public ConsumidorController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @Operation(
        summary = "Consumir/registrar un pedido",
        description = "Valida los datos recibidos y registra el pedido en el sistema"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Pedido registrado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping("/consume")
    public ResponseEntity<PedidoResponseDTO> consumirPedido(@RequestBody PedidoRequestDTO dto) {
        if (!pedidoService.datosValidos(dto)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        PedidoResponseDTO nuevo = pedidoService.guardar(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevo);
    }

    @Operation(
        summary = "Listar pedidos (vista consumidor)",
        description = "Obtiene todos los pedidos registrados en la base de datos"
    )
    @ApiResponse(
        responseCode = "200",
        description = "Listado de pedidos obtenido correctamente"
    )
    @GetMapping("/pedidos")
    public ResponseEntity<?> listarPedidosConsumidor() {
        return ResponseEntity.ok(pedidoService.listarPedidos());
    }
}
