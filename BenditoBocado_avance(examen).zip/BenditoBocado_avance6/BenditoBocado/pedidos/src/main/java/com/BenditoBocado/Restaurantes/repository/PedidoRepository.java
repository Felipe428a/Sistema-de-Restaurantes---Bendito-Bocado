package com.BenditoBocado.Restaurantes.repository;

import com.BenditoBocado.Restaurantes.model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepository extends JpaRepository<Pedido, Integer> {
}
