package com.BenditoBocado.Restaurantes.controller;

import com.BenditoBocado.Restaurantes.dto.PedidoRequestDTO;
import com.BenditoBocado.Restaurantes.dto.PedidoResponseDTO;
import com.BenditoBocado.Restaurantes.service.MenuConsumerService;
import com.BenditoBocado.Restaurantes.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Tag(
    name = "Pedidos",
    description = "Endpoints para gestionar pedidos del sistema"
)
@RestController
@RequestMapping("/api/v1/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;
    private final MenuConsumerService menuConsumer;

    public PedidoController(PedidoService pedidoService, MenuConsumerService menuConsumer) {
        this.pedidoService = pedidoService;
        this.menuConsumer = menuConsumer;
    }

    @Operation(
        summary = "Listar pedidos",
        description = "Obtiene todos los pedidos registrados en la base de datos"
    )
    @ApiResponse(
        responseCode = "200",
        description = "Listado de pedidos obtenido correctamente"
    )
    @GetMapping
    public ResponseEntity<List<PedidoResponseDTO>> listar() {
        return ResponseEntity.ok(pedidoService.listarPedidos());
    }

    @Operation(
        summary = "Buscar pedido por ID",
        description = "Obtiene un pedido específico usando su identificador. " +
                "La respuesta incluye enlaces HATEOAS (_links) hacia el propio recurso y hacia el listado de pedidos."
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Pedido encontrado"),
        @ApiResponse(responseCode = "404", description = "Pedido no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "ID del pedido", example = "1")
            @PathVariable Integer id) {

        PedidoResponseDTO pedido = pedidoService.buscarPorId(id);
        if (pedido == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Pedido no encontrado");
        }

        // Envolvemos el DTO en un EntityModel para poder agregarle enlaces (HATEOAS)
        EntityModel<PedidoResponseDTO> recurso = EntityModel.of(pedido);

        // Link "self": apunta al propio recurso que se está devolviendo
        recurso.add(linkTo(methodOn(PedidoController.class).buscarPorId(id)).withSelfRel());

        // Link relacionado: apunta al listado completo de pedidos
        recurso.add(linkTo(methodOn(PedidoController.class).listar()).withRel("pedidos"));

        return ResponseEntity.ok(recurso);
    }

    @Operation(
        summary = "Crear pedido",
        description = "Registra un nuevo pedido en el sistema"
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Pedido creado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public ResponseEntity<PedidoResponseDTO> guardar(
            @Valid @RequestBody PedidoRequestDTO dto) {

        PedidoResponseDTO creado = pedidoService.guardar(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @Operation(
        summary = "Listar platos disponibles",
        description = "Obtiene los platos disponibles del servicio remoto"
    )
    @ApiResponse(
        responseCode = "200",
        description = "Platos disponibles obtenidos correctamente"
    )
    @GetMapping("/platos-disponibles")
    public ResponseEntity<?> obtenerPlatosDisponibles() {
        return ResponseEntity.ok(menuConsumer.fetchPlatos());
    }

    @Operation(
        summary = "Asignar repartidor a un pedido",
        description = "Valida contra el microservicio repartidores (via Feign) que el repartidor " +
                "exista y esté disponible, y lo asigna al pedido."
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Repartidor asignado correctamente"),
        @ApiResponse(responseCode = "404", description = "Pedido no encontrado"),
        @ApiResponse(responseCode = "409", description = "Repartidor no disponible o servicio repartidores caído")
    })
    @PutMapping("/{id}/repartidor/{repartidorId}")
    public ResponseEntity<?> asignarRepartidor(
            @PathVariable Integer id,
            @PathVariable Integer repartidorId) {
        try {
            return ResponseEntity.ok(pedidoService.asignarRepartidor(id, repartidorId));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        }
    }

    @Operation(
        summary = "Vincular pago a un pedido",
        description = "Uso interno: el microservicio pagos llama a este endpoint (via Feign) " +
                "para vincular el pago generado con el pedido correspondiente."
    )
    @PutMapping("/{id}/pago/{pagoId}")
    public ResponseEntity<?> vincularPago(
            @PathVariable Integer id,
            @PathVariable Integer pagoId) {
        try {
            return ResponseEntity.ok(pedidoService.vincularPago(id, pagoId));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
