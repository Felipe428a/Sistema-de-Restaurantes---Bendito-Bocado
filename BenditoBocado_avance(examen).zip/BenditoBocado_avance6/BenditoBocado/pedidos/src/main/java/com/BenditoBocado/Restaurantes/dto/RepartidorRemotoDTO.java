package com.BenditoBocado.Restaurantes.dto;

// Representa el Repartidor del microservicio "repartidores", tal como lo
// consume "pedidos" via Feign al asignar un repartidor a un pedido.
public class RepartidorRemotoDTO {
    private int id;
    private String nombre;
    private String estado;
    private boolean disponibilidad;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public boolean isDisponibilidad() { return disponibilidad; }
    public void setDisponibilidad(boolean disponibilidad) { this.disponibilidad = disponibilidad; }
}
