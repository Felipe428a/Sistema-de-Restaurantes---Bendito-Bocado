package com.BenditoBocado.Restaurantes.service;

import com.BenditoBocado.Restaurantes.client.MenusClient;
import com.BenditoBocado.Restaurantes.dto.PlatoDTORemoto;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

/**
 * Antes llamaba a Menus por RestTemplate + URL fija (app.menus.url).
 * Ahora usa un cliente Feign que resuelve el servicio "menus" via Eureka.
 */
@Service
public class MenuConsumerService {

    private final MenusClient menusClient;

    public MenuConsumerService(MenusClient menusClient) {
        this.menusClient = menusClient;
    }

    public List<PlatoDTORemoto> fetchPlatos() {
        try {
            List<PlatoDTORemoto> platos = menusClient.obtenerPlatos();
            return platos != null ? platos : Collections.emptyList();
        } catch (Exception ex) {
            return Collections.emptyList();
        }
    }
}
