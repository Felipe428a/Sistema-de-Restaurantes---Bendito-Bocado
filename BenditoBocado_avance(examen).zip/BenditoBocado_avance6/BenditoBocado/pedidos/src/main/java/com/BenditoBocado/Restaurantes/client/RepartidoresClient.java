package com.BenditoBocado.Restaurantes.client;

import com.BenditoBocado.Restaurantes.config.FeignConfig;
import com.BenditoBocado.Restaurantes.dto.RepartidorRemotoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// Cliente Feign hacia el microservicio "repartidores", resuelto por nombre
// a traves de Eureka. Usado para validar disponibilidad antes de asignar
// un repartidor a un pedido.
@FeignClient(name = "repartidores", configuration = FeignConfig.class, fallback = RepartidoresClientFallback.class)
public interface RepartidoresClient {

    @GetMapping("/api/v1/repartidores/{id}")
    RepartidorRemotoDTO obtenerRepartidor(@PathVariable("id") int id);
}
