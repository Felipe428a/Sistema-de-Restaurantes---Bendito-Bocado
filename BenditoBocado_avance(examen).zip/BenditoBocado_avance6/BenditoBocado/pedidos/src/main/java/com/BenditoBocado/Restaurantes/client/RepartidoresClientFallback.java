package com.BenditoBocado.Restaurantes.client;

import com.BenditoBocado.Restaurantes.dto.RepartidorRemotoDTO;
import org.springframework.stereotype.Component;

@Component
public class RepartidoresClientFallback implements RepartidoresClient {

    @Override
    public RepartidorRemotoDTO obtenerRepartidor(int id) {
        return null;
    }
}
