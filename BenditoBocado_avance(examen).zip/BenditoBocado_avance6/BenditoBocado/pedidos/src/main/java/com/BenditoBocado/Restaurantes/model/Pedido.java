package com.BenditoBocado.Restaurantes.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "pedidos")
public class Pedido {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(nullable = false)
  private String nombreCliente;

  @Column(nullable = false)
  private String platos;

  @Column(nullable = false)
  private LocalDate fecha;

  @Column(nullable = false)
  private String estado;

  @Column(nullable = false)
  private Double total;

  @Column(nullable = false)
  private Integer mesa;

  // FK logica hacia el repartidor asignado en el microservicio "repartidores".
  @Column(name = "repartidor_id")
  private Integer repartidorId;

  // FK logica hacia el pago asociado en el microservicio "pagos".
  @Column(name = "pago_id")
  private Integer pagoId;

  public Pedido() {
  }

  public Pedido(Integer id, String nombreCliente, String platos, LocalDate fecha,
                String estado, Double total, Integer mesa) {
    this.id = id;
    this.nombreCliente = nombreCliente;
    this.platos = platos;
    this.fecha = fecha;
    this.estado = estado;
    this.total = total;
    this.mesa = mesa;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getNombreCliente() {
    return nombreCliente;
  }

  public void setNombreCliente(String nombreCliente) {
    this.nombreCliente = nombreCliente;
  }

  public String getPlatos() {
    return platos;
  }

  public void setPlatos(String platos) {
    this.platos = platos;
  }

  public LocalDate getFecha() {
    return fecha;
  }

  public void setFecha(LocalDate fecha) {
    this.fecha = fecha;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }

  public Double getTotal() {
    return total;
  }

  public void setTotal(Double total) {
    this.total = total;
  }

  public Integer getMesa() {
    return mesa;
  }

  public void setMesa(Integer mesa) {
    this.mesa = mesa;
  }

  public Integer getRepartidorId() {
    return repartidorId;
  }

  public void setRepartidorId(Integer repartidorId) {
    this.repartidorId = repartidorId;
  }

  public Integer getPagoId() {
    return pagoId;
  }

  public void setPagoId(Integer pagoId) {
    this.pagoId = pagoId;
  }
}
