package com.BenditoBocado.Restaurantes.service;

import com.BenditoBocado.Restaurantes.client.RepartidoresClient;
import com.BenditoBocado.Restaurantes.dto.PedidoRequestDTO;
import com.BenditoBocado.Restaurantes.dto.PedidoResponseDTO;
import com.BenditoBocado.Restaurantes.dto.RepartidorRemotoDTO;
import com.BenditoBocado.Restaurantes.model.Pedido;
import com.BenditoBocado.Restaurantes.repository.PedidoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;
    private final RepartidoresClient repartidoresClient;

    public PedidoService(PedidoRepository pedidoRepository, RepartidoresClient repartidoresClient) {
        this.pedidoRepository = pedidoRepository;
        this.repartidoresClient = repartidoresClient;
    }

    // Pedidos <-> Repartidores: valida contra el microservicio "repartidores"
    // (via Feign) que el repartidor exista y este disponible, y lo asigna al pedido.
    // Lanza IllegalArgumentException / IllegalStateException que el controller traduce a 404/409.
    public PedidoResponseDTO asignarRepartidor(Integer pedidoId, Integer repartidorId) {
        Pedido pedido = pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new IllegalArgumentException("Pedido no encontrado: " + pedidoId));

        RepartidorRemotoDTO repartidor = repartidoresClient.obtenerRepartidor(repartidorId);
        if (repartidor == null) {
            throw new IllegalStateException(
                    "No se pudo validar el repartidor " + repartidorId + " (servicio repartidores no disponible)");
        }
        if (!repartidor.isDisponibilidad()) {
            throw new IllegalStateException("El repartidor " + repartidorId + " no está disponible");
        }

        pedido.setRepartidorId(repartidorId);
        return toResponseDTO(pedidoRepository.save(pedido));
    }

    // Usado por "pagos" (via Feign) para vincular el pago generado a este pedido.
    public PedidoResponseDTO vincularPago(Integer pedidoId, Integer pagoId) {
        Pedido pedido = pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new IllegalArgumentException("Pedido no encontrado: " + pedidoId));
        pedido.setPagoId(pagoId);
        return toResponseDTO(pedidoRepository.save(pedido));
    }

    public List<PedidoResponseDTO> listarPedidos() {
        return pedidoRepository.findAll().stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    public PedidoResponseDTO buscarPorId(Integer id) {
        Optional<Pedido> pedidoOpt = pedidoRepository.findById(id);
        return pedidoOpt.map(this::toResponseDTO).orElse(null);
    }

    public PedidoResponseDTO guardar(PedidoRequestDTO dto) {
        Pedido pedido = fromRequestDTO(dto);
        if (pedido.getFecha() == null) {
            pedido.setFecha(LocalDate.now());
        }
        Pedido guardado = pedidoRepository.save(pedido);
        return toResponseDTO(guardado);
    }

    public boolean datosValidos(PedidoRequestDTO dto) {
        if (dto == null) {
            return false;
        }
        if (dto.getNombreCliente() == null || dto.getNombreCliente().isBlank()) {
            return false;
        }
        if (dto.getPlatos() == null || dto.getPlatos().isBlank()) {
            return false;
        }
        if (dto.getEstado() == null || dto.getEstado().isBlank()) {
            return false;
        }
        if (dto.getMesa() <= 0) {
            return false;
        }
        return true;
    }

    private PedidoResponseDTO toResponseDTO(Pedido pedido) {
        return new PedidoResponseDTO(
                pedido.getId(),
                pedido.getNombreCliente(),
                pedido.getPlatos(),
                pedido.getFecha(),
                pedido.getEstado(),
                pedido.getTotal(),
                pedido.getMesa(),
                pedido.getRepartidorId(),
                pedido.getPagoId()
        );
    }

    private Pedido fromRequestDTO(PedidoRequestDTO dto) {
        Pedido pedido = new Pedido();
        pedido.setNombreCliente(dto.getNombreCliente());
        pedido.setPlatos(dto.getPlatos());
        pedido.setEstado(dto.getEstado());
        pedido.setMesa(dto.getMesa());
        pedido.setTotal(dto.getTotal() != null ? dto.getTotal() : 0.0);
        pedido.setFecha(dto.getFecha() != null ? dto.getFecha() : LocalDate.now());
        return pedido;
    }
}
