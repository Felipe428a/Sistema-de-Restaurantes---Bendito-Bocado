package com.BenditoBocado.Restaurantes.client;

import com.BenditoBocado.Restaurantes.dto.PlatoDTORemoto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * Cliente Feign hacia el microservicio "menus", resuelto por nombre a
 * traves de Eureka (spring.application.name=menus) en lugar de una URL
 * fija a localhost:8082.
 */
@FeignClient(name = "menus")
public interface MenusClient {

    @GetMapping("/api/v1/platos")
    List<PlatoDTORemoto> obtenerPlatos();
}
