package com.BenditoBocado.Restaurantes.dto;

import java.time.LocalDate;

import org.springframework.hateoas.RepresentationModel;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Datos de un pedido tal como se devuelven al cliente")
public class PedidoResponseDTO extends RepresentationModel<PedidoResponseDTO> {

    @Schema(description = "Identificador único del pedido", example = "1")
    private Integer id;

    @Schema(description = "Nombre del cliente que realizó el pedido", example = "Juan Pérez")
    private String nombreCliente;

    @Schema(description = "Platos incluidos en el pedido", example = "Pastel de choclo, Bebida")
    private String platos;

    @Schema(description = "Fecha en que se registró el pedido", example = "2026-06-21")
    private LocalDate fecha;

    @Schema(description = "Estado actual del pedido", example = "PENDIENTE")
    private String estado;

    @Schema(description = "Monto total del pedido", example = "8500.0")
    private Double total;

    @Schema(description = "Número de mesa asociado al pedido", example = "4")
    private Integer mesa;

    @Schema(description = "ID del repartidor asignado a este pedido (microservicio repartidores)", example = "2")
    private Integer repartidorId;

    @Schema(description = "ID del pago asociado a este pedido (microservicio pagos)", example = "5")
    private Integer pagoId;

    public PedidoResponseDTO() {
    }

    public PedidoResponseDTO(Integer id, String nombreCliente, String platos, LocalDate fecha,
                              String estado, Double total, Integer mesa) {
        this.id = id;
        this.nombreCliente = nombreCliente;
        this.platos = platos;
        this.fecha = fecha;
        this.estado = estado;
        this.total = total;
        this.mesa = mesa;
    }

    public PedidoResponseDTO(Integer id, String nombreCliente, String platos, LocalDate fecha,
                              String estado, Double total, Integer mesa,
                              Integer repartidorId, Integer pagoId) {
        this(id, nombreCliente, platos, fecha, estado, total, mesa);
        this.repartidorId = repartidorId;
        this.pagoId = pagoId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getPlatos() {
        return platos;
    }

    public void setPlatos(String platos) {
        this.platos = platos;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Integer getMesa() {
        return mesa;
    }

    public void setMesa(Integer mesa) {
        this.mesa = mesa;
    }

    public Integer getRepartidorId() {
        return repartidorId;
    }

    public void setRepartidorId(Integer repartidorId) {
        this.repartidorId = repartidorId;
    }

    public Integer getPagoId() {
        return pagoId;
    }

    public void setPagoId(Integer pagoId) {
        this.pagoId = pagoId;
    }
}
