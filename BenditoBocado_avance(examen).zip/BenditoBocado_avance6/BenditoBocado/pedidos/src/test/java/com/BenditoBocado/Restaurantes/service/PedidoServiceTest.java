package com.BenditoBocado.Restaurantes.service;

import com.BenditoBocado.Restaurantes.client.RepartidoresClient;
import com.BenditoBocado.Restaurantes.dto.PedidoRequestDTO;
import com.BenditoBocado.Restaurantes.dto.PedidoResponseDTO;
import com.BenditoBocado.Restaurantes.dto.RepartidorRemotoDTO;
import com.BenditoBocado.Restaurantes.model.Pedido;
import com.BenditoBocado.Restaurantes.repository.PedidoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Pruebas unitarias de la capa Service (PedidoService).
 * No se usa base de datos real: PedidoRepository se simula con Mockito.
 */
@ExtendWith(MockitoExtension.class)
class PedidoServiceTest {

    // Simula el Repository, sin tocar la base de datos real
    @Mock
    private PedidoRepository pedidoRepository;

    // Simula el cliente Feign hacia "repartidores" (Pedidos <-> Repartidores)
    @Mock
    private RepartidoresClient repartidoresClient;

    // Crea PedidoService e inyecta automáticamente los mocks anteriores
    @InjectMocks
    private PedidoService pedidoService;

    private Pedido pedidoGuardado;
    private PedidoRequestDTO requestValido;

    @BeforeEach
    void setUp() {
        pedidoGuardado = new Pedido(1, "Juan Pérez", "Pastel de choclo", LocalDate.now(),
                "PENDIENTE", 8500.0, 4);

        requestValido = new PedidoRequestDTO();
        requestValido.setNombreCliente("Juan Pérez");
        requestValido.setPlatos("Pastel de choclo");
        requestValido.setEstado("PENDIENTE");
        requestValido.setMesa(4);
        requestValido.setTotal(8500.0);
    }

    @Test
    void guardar_conDatosValidos_deberiaRetornarPedidoCreado() {
        // Given: el repository simula que guarda y devuelve el pedido con id asignado
        when(pedidoRepository.save(any(Pedido.class))).thenReturn(pedidoGuardado);

        // When: se invoca el método del service que se está probando
        PedidoResponseDTO resultado = pedidoService.guardar(requestValido);

        // Then: se valida el resultado y que el repository fue invocado una vez
        assertNotNull(resultado);
        assertEquals(1, resultado.getId());
        assertEquals("Juan Pérez", resultado.getNombreCliente());
        assertEquals("PENDIENTE", resultado.getEstado());
        verify(pedidoRepository, times(1)).save(any(Pedido.class));
    }

    @Test
    void guardar_sinFecha_deberiaAsignarFechaActual() {
        // Given: el DTO no trae fecha
        requestValido.setFecha(null);
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        PedidoResponseDTO resultado = pedidoService.guardar(requestValido);

        // Then
        assertNotNull(resultado.getFecha());
        assertEquals(LocalDate.now(), resultado.getFecha());
    }

    @Test
    void buscarPorId_cuandoElPedidoExiste_deberiaRetornarlo() {
        // Given
        when(pedidoRepository.findById(1)).thenReturn(Optional.of(pedidoGuardado));

        // When
        PedidoResponseDTO resultado = pedidoService.buscarPorId(1);

        // Then
        assertNotNull(resultado);
        assertEquals(1, resultado.getId());
        verify(pedidoRepository, times(1)).findById(1);
    }

    @Test
    void buscarPorId_cuandoNoExiste_deberiaRetornarNull() {
        // Given
        when(pedidoRepository.findById(99)).thenReturn(Optional.empty());

        // When
        PedidoResponseDTO resultado = pedidoService.buscarPorId(99);

        // Then
        assertNull(resultado);
    }

    @Test
    void listarPedidos_deberiaRetornarTodosLosPedidosMapeados() {
        // Given
        when(pedidoRepository.findAll()).thenReturn(List.of(pedidoGuardado));

        // When
        List<PedidoResponseDTO> resultado = pedidoService.listarPedidos();

        // Then
        assertEquals(1, resultado.size());
        assertEquals("Pastel de choclo", resultado.get(0).getPlatos());
    }

    @Test
    void datosValidos_conMesaMenorOIgualACero_deberiaRetornarFalse() {
        // Given
        requestValido.setMesa(0);

        // When
        boolean valido = pedidoService.datosValidos(requestValido);

        // Then
        assertFalse(valido);
    }

    @Test
    void datosValidos_conNombreClienteVacio_deberiaRetornarFalse() {
        // Given
        requestValido.setNombreCliente("  ");

        // When
        boolean valido = pedidoService.datosValidos(requestValido);

        // Then
        assertFalse(valido);
    }

    @Test
    void datosValidos_conTodosLosCamposCorrectos_deberiaRetornarTrue() {
        // When
        boolean valido = pedidoService.datosValidos(requestValido);

        // Then
        assertTrue(valido);
    }

    @Test
    void datosValidos_conDtoNulo_deberiaRetornarFalse() {
        // When
        boolean valido = pedidoService.datosValidos(null);

        // Then
        assertFalse(valido);
    }

    @Test
    void asignarRepartidor_pedidoNoExiste_lanzaExcepcion() {
        when(pedidoRepository.findById(99)).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> pedidoService.asignarRepartidor(99, 2));
        verify(repartidoresClient, never()).obtenerRepartidor(anyInt());
    }

    @Test
    void asignarRepartidor_repartidorNoResponde_lanzaExcepcion() {
        when(pedidoRepository.findById(1)).thenReturn(Optional.of(pedidoGuardado));
        when(repartidoresClient.obtenerRepartidor(2)).thenReturn(null); // fallback

        assertThrows(IllegalStateException.class, () -> pedidoService.asignarRepartidor(1, 2));
        verify(pedidoRepository, never()).save(any());
    }

    @Test
    void asignarRepartidor_repartidorNoDisponible_lanzaExcepcion() {
        when(pedidoRepository.findById(1)).thenReturn(Optional.of(pedidoGuardado));
        RepartidorRemotoDTO repartidor = new RepartidorRemotoDTO();
        repartidor.setId(2);
        repartidor.setDisponibilidad(false);
        when(repartidoresClient.obtenerRepartidor(2)).thenReturn(repartidor);

        assertThrows(IllegalStateException.class, () -> pedidoService.asignarRepartidor(1, 2));
        verify(pedidoRepository, never()).save(any());
    }

    @Test
    void asignarRepartidor_repartidorDisponible_deberiaAsignarYRetornar() {
        when(pedidoRepository.findById(1)).thenReturn(Optional.of(pedidoGuardado));
        RepartidorRemotoDTO repartidor = new RepartidorRemotoDTO();
        repartidor.setId(2);
        repartidor.setDisponibilidad(true);
        when(repartidoresClient.obtenerRepartidor(2)).thenReturn(repartidor);
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(inv -> inv.getArgument(0));

        PedidoResponseDTO resultado = pedidoService.asignarRepartidor(1, 2);

        assertEquals(2, resultado.getRepartidorId());
    }

    @Test
    void vincularPago_pedidoNoExiste_lanzaExcepcion() {
        when(pedidoRepository.findById(99)).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> pedidoService.vincularPago(99, 5));
    }

    @Test
    void vincularPago_pedidoExiste_deberiaVincularYRetornar() {
        when(pedidoRepository.findById(1)).thenReturn(Optional.of(pedidoGuardado));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(inv -> inv.getArgument(0));

        PedidoResponseDTO resultado = pedidoService.vincularPago(1, 5);

        assertEquals(5, resultado.getPagoId());
    }
}
