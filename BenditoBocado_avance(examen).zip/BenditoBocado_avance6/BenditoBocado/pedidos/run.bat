@echo off
REM Script para ejecutar el jar usando java desde PATH (no requiere JAVA_HOME)
setlocal enabledelayedexpansion

nREM Buscar jar en target
set JAR=
for %%f in (target\*.jar) do set JAR=%%f
if "%JAR%"=="" (
  echo No se encontro ningun jar en target. Ejecute: mvnw package  (o mvn package)
  exit /b 1
)

nREM Comprobar java en PATH
where java >nul 2>&1
if errorlevel 1 (
  echo 'java' no encontrado en PATH. Instale Java y agreguelo al PATH.
  exit /b 1
)

necho Ejecutando %JAR% ...
java -jar "%JAR%"
endlocal
