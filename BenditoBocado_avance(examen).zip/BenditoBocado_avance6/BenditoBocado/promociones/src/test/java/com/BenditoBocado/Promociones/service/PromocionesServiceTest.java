package com.BenditoBocado.Promociones.service;

import com.BenditoBocado.Promociones.model.Promociones;
import com.BenditoBocado.Promociones.repository.PromocionesRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PromocionesServiceTest {

    @Mock
    private PromocionesRepository promocionesRepository;

    @InjectMocks
    private PromocionesService promocionesService;

    private Promociones promocion;

    @BeforeEach
    void setUp() {
        promocion = new Promociones(1, "2x1 Empanadas", "DESCUENTO",
                LocalDate.now(), LocalDate.now().plusDays(10),
                "Promo de lanzamiento", "ACTIVA", 100);
    }

    @Test
    void listarPromociones_deberiaRetornarTodas() {
        when(promocionesRepository.findAll()).thenReturn(List.of(promocion));

        List<Promociones> resultado = promocionesService.listarPromociones();

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorId_cuandoExiste_deberiaRetornarla() {
        when(promocionesRepository.findById(1)).thenReturn(Optional.of(promocion));

        Optional<Promociones> resultado = promocionesService.buscarPorId(1);

        assertTrue(resultado.isPresent());
    }

    @Test
    void agregarPromociones_deberiaGuardarYRetornar() {
        when(promocionesRepository.save(any(Promociones.class))).thenReturn(promocion);

        Promociones resultado = promocionesService.agregarPromociones(promocion);

        assertNotNull(resultado);
    }

    @Test
    void datosValidos_conDatosCompletos_deberiaRetornarTrue() {
        assertTrue(promocionesService.datosValidos(promocion));
    }

    @Test
    void datosValidos_fechaFinAntesQueInicio_deberiaRetornarFalse() {
        promocion.setFechaFin(promocion.getFechaInicio().minusDays(1));
        assertFalse(promocionesService.datosValidos(promocion));
    }

    @Test
    void datosValidos_sinNombre_deberiaRetornarFalse() {
        promocion.setNombre("");
        assertFalse(promocionesService.datosValidos(promocion));
    }

    @Test
    void datosValidos_cuposNegativos_deberiaRetornarFalse() {
        promocion.setCuposDisponibles(-5);
        assertFalse(promocionesService.datosValidos(promocion));
    }
}
