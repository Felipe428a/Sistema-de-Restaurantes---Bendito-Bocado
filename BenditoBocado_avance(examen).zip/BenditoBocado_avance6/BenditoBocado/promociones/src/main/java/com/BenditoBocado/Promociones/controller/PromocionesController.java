package com.BenditoBocado.Promociones.controller;

import com.BenditoBocado.Promociones.dto.PromocionesRequestDTO;
import com.BenditoBocado.Promociones.model.Promociones;
import com.BenditoBocado.Promociones.service.PromocionesService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/promociones")
@CrossOrigin(origins = "*")
public class PromocionesController {

    private final PromocionesService promocionesService;

    public PromocionesController(PromocionesService promocionesService) {
        this.promocionesService = promocionesService;
    }

    @GetMapping
    public ResponseEntity<List<Promociones>> obtenerPromociones() {
        return ResponseEntity.ok(promocionesService.listarPromociones());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Promociones> obtenerPorId(@PathVariable int id) {
        return promocionesService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> crearPromociones(@Valid @RequestBody PromocionesRequestDTO requestDTO) {
        Promociones promociones = requestDTO.toEntity();
        if (!promocionesService.datosValidos(promociones)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Datos de la promoción inválidos");
        }
        Promociones nuevaPromociones = promocionesService.agregarPromociones(promociones);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevaPromociones);
    }
}
