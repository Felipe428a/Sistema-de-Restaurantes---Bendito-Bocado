package com.BenditoBocado.Promociones.repository;

import com.BenditoBocado.Promociones.model.Promociones;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PromocionesRepository extends JpaRepository<Promociones, Integer> {
}
