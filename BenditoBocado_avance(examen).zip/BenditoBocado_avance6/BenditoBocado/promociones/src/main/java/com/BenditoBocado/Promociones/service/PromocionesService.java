package com.BenditoBocado.Promociones.service;

import com.BenditoBocado.Promociones.model.Promociones;
import com.BenditoBocado.Promociones.repository.PromocionesRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PromocionesService {

    private final PromocionesRepository promocionesRepository;

    public PromocionesService(PromocionesRepository promocionesRepository) {
        this.promocionesRepository = promocionesRepository;
    }

    public List<Promociones> listarPromociones() {
        return promocionesRepository.findAll();
    }

    // Usado por "menus" y "pagos" (via Feign) para validar una promocion antes
    // de aplicarla a un plato o a un pago.
    public Optional<Promociones> buscarPorId(int id) {
        return promocionesRepository.findById(id);
    }

    public Promociones agregarPromociones(Promociones promociones) {
        return promocionesRepository.save(promociones);
    }

    public boolean datosValidos(Promociones promociones) {
        if (promociones.getNombre() == null || promociones.getNombre().isBlank()) {
            return false;
        }
        if (promociones.getTipo() == null || promociones.getTipo().isBlank()) {
            return false;
        }
        if (promociones.getFechaInicio() == null || promociones.getFechaFin() == null) {
            return false;
        }
        if (promociones.getFechaFin().isBefore(promociones.getFechaInicio())) {
            return false;
        }
        if (promociones.getDescripcion() == null || promociones.getDescripcion().isBlank()) {
            return false;
        }
        if (promociones.getEstado() == null || promociones.getEstado().isBlank()) {
            return false;
        }
        return promociones.getCuposDisponibles() >= 0;
    }
}
