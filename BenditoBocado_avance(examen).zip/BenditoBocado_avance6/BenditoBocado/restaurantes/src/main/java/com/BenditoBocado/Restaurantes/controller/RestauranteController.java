package com.BenditoBocado.Restaurantes.controller;

import com.BenditoBocado.Restaurantes.dto.RestauranteRequestDTO;
import com.BenditoBocado.Restaurantes.model.Restaurante;
import com.BenditoBocado.Restaurantes.service.RestauranteService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/restaurantes")
public class RestauranteController {

    private final RestauranteService restauranteService;

    public RestauranteController(RestauranteService restauranteService) {
        this.restauranteService = restauranteService;
    }

    @GetMapping
    public ResponseEntity<List<Restaurante>> obtenerRestaurantes() {
        return ResponseEntity.ok(restauranteService.listarRestaurantes());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Restaurante> obtenerRestaurante(@PathVariable Integer id) {
        return restauranteService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Restaurante> crearRestaurante(@Valid @RequestBody RestauranteRequestDTO restauranteDTO) {
        Restaurante restaurante = new Restaurante();
        restaurante.setNombre(restauranteDTO.getNombre());
        restaurante.setTipo(restauranteDTO.getTipo());
        restaurante.setDireccion(restauranteDTO.getDireccion());
        restaurante.setTelefono(restauranteDTO.getTelefono());
        restaurante.setHorario(restauranteDTO.getHorario());
        restaurante.setEstado(restauranteDTO.getEstado());
        restaurante.setCapacidad(restauranteDTO.getCapacidad());

        Restaurante nuevo = restauranteService.agregarRestaurante(restaurante);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevo);
    }
}
