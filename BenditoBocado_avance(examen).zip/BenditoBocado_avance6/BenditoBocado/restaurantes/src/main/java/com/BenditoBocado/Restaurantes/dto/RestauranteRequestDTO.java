package com.BenditoBocado.Restaurantes.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public class RestauranteRequestDTO {

    @NotBlank(message = "El nombre del restaurante es obligatorio")
    private String nombre;

    @NotBlank(message = "El tipo de restaurante es obligatorio")
    private String tipo;

    @NotBlank(message = "La dirección del restaurante es obligatoria")
    private String direccion;

    @NotBlank(message = "El teléfono del restaurante es obligatorio")
    private String telefono;

    @NotBlank(message = "El horario del restaurante es obligatorio")
    private String horario;

    @NotBlank(message = "El estado del restaurante es obligatorio")
    private String estado;

    @Min(value = 1, message = "La capacidad debe ser mayor que cero")
    private int capacidad;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
}
