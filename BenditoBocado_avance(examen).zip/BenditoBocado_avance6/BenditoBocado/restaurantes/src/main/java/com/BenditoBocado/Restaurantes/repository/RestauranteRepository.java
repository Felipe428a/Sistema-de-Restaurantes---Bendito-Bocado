package com.BenditoBocado.Restaurantes.repository;

import com.BenditoBocado.Restaurantes.model.Restaurante;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RestauranteRepository extends JpaRepository<Restaurante, Integer> {

}
