package com.BenditoBocado.Restaurantes.service;

import com.BenditoBocado.Restaurantes.model.Restaurante;
import com.BenditoBocado.Restaurantes.repository.RestauranteRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RestauranteService {

    private final RestauranteRepository restauranteRepository;

    public RestauranteService(RestauranteRepository restauranteRepository) {
        this.restauranteRepository = restauranteRepository;
    }

    public List<Restaurante> listarRestaurantes() {
        return restauranteRepository.findAll();
    }

    public Restaurante agregarRestaurante(Restaurante restaurante) {
        return restauranteRepository.save(restaurante);
    }

    // Usado por "clientes" (via Feign) para validar el restaurante antes de
    // registrar una calificacion/reseña.
    public Optional<Restaurante> buscarPorId(Integer id) {
        return restauranteRepository.findById(id);
    }

    public boolean datosValidos(Restaurante restaurante) {
        if (restaurante.getNombre() == null || restaurante.getNombre().isBlank()) {
            return false;
        }
        if (restaurante.getTipo() == null || restaurante.getTipo().isBlank()) {
            return false;
        }
        if (restaurante.getDireccion() == null || restaurante.getDireccion().isBlank()) {
            return false;
        }
        if (restaurante.getTelefono() == null || restaurante.getTelefono().isBlank()) {
            return false;
        }
        if (restaurante.getHorario() == null || restaurante.getHorario().isBlank()) {
            return false;
        }
        if (restaurante.getEstado() == null || restaurante.getEstado().isBlank()) {
            return false;
        }
        if (restaurante.getCapacidad() < 0) {
            return false;
        }
        return true;
    }
}
