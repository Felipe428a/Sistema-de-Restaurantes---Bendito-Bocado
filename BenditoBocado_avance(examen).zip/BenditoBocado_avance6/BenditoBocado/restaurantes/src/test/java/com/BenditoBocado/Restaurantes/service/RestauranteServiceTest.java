package com.BenditoBocado.Restaurantes.service;

import com.BenditoBocado.Restaurantes.model.Restaurante;
import com.BenditoBocado.Restaurantes.repository.RestauranteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RestauranteServiceTest {

    @Mock
    private RestauranteRepository restauranteRepository;

    @InjectMocks
    private RestauranteService restauranteService;

    private Restaurante restaurante;

    @BeforeEach
    void setUp() {
        restaurante = new Restaurante();
        restaurante.setId(1);
        restaurante.setNombre("Cocinerias Doña Rosa");
        restaurante.setTipo("Chilena");
        restaurante.setDireccion("Calle Falsa 123");
        restaurante.setTelefono("+56933333333");
        restaurante.setHorario("09:00-22:00");
        restaurante.setEstado("ACTIVO");
        restaurante.setCapacidad(40);
    }

    @Test
    void listarRestaurantes_deberiaRetornarTodos() {
        when(restauranteRepository.findAll()).thenReturn(List.of(restaurante));

        List<Restaurante> resultado = restauranteService.listarRestaurantes();

        assertEquals(1, resultado.size());
    }

    @Test
    void agregarRestaurante_deberiaGuardarYRetornar() {
        when(restauranteRepository.save(any(Restaurante.class))).thenReturn(restaurante);

        Restaurante resultado = restauranteService.agregarRestaurante(restaurante);

        assertNotNull(resultado);
        assertEquals("Cocinerias Doña Rosa", resultado.getNombre());
    }

    @Test
    void buscarPorId_cuandoExiste_deberiaRetornarlo() {
        when(restauranteRepository.findById(1)).thenReturn(Optional.of(restaurante));

        Optional<Restaurante> resultado = restauranteService.buscarPorId(1);

        assertTrue(resultado.isPresent());
    }

    @Test
    void buscarPorId_cuandoNoExiste_deberiaRetornarEmpty() {
        when(restauranteRepository.findById(99)).thenReturn(Optional.empty());

        Optional<Restaurante> resultado = restauranteService.buscarPorId(99);

        assertTrue(resultado.isEmpty());
    }

    @Test
    void datosValidos_conDatosCompletos_deberiaRetornarTrue() {
        assertTrue(restauranteService.datosValidos(restaurante));
    }

    @Test
    void datosValidos_capacidadNegativa_deberiaRetornarFalse() {
        restaurante.setCapacidad(-1);
        assertFalse(restauranteService.datosValidos(restaurante));
    }

    @Test
    void datosValidos_sinTelefono_deberiaRetornarFalse() {
        restaurante.setTelefono("");
        assertFalse(restauranteService.datosValidos(restaurante));
    }
}
