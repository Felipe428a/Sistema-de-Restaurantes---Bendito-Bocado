-- Se ejecuta automaticamente la PRIMERA vez que el contenedor mysql crea su
-- volumen de datos (docker-entrypoint-initdb.d). Si ya existe el volumen,
-- este script NO se vuelve a correr (borra el volumen si necesitas resetear).

CREATE DATABASE IF NOT EXISTS restaurantes_db;
CREATE DATABASE IF NOT EXISTS stock_db;
CREATE DATABASE IF NOT EXISTS promociones_db;
CREATE DATABASE IF NOT EXISTS clientes_db;
CREATE DATABASE IF NOT EXISTS repartidores_db;
CREATE DATABASE IF NOT EXISTS direcciones_db;
CREATE DATABASE IF NOT EXISTS pagos_db;
