package com.BenditoBocado.Restaurantes.dto;

import com.BenditoBocado.Restaurantes.model.Plato;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class PlatoDTO {

    private Integer id;

    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;

    @Size(max = 1000, message = "La descripción no puede exceder 1000 caracteres")
    private String descripcion;

    @NotNull(message = "El precio es obligatorio")
    @DecimalMin(value = "0.0", inclusive = true, message = "El precio debe ser mayor o igual a 0")
    private BigDecimal precio;

    @NotBlank(message = "La categoría es obligatoria")
    private String categoria;

    private boolean disponible;

    @Min(value = 0, message = "El tiempo de preparación debe ser >= 0")
    private int tiempoPreparacion;

    private Integer productoId;

    private Integer promocionId;

    public PlatoDTO() {}

    public PlatoDTO(Integer id, String nombre, String descripcion, BigDecimal precio, String categoria, boolean disponible, int tiempoPreparacion) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.categoria = categoria;
        this.disponible = disponible;
        this.tiempoPreparacion = tiempoPreparacion;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getPrecio() { return precio; }
    public void setPrecio(BigDecimal precio) { this.precio = precio; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public boolean isDisponible() { return disponible; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }

    public int getTiempoPreparacion() { return tiempoPreparacion; }
    public void setTiempoPreparacion(int tiempoPreparacion) { this.tiempoPreparacion = tiempoPreparacion; }

    public Integer getProductoId() { return productoId; }
    public void setProductoId(Integer productoId) { this.productoId = productoId; }

    public Integer getPromocionId() { return promocionId; }
    public void setPromocionId(Integer promocionId) { this.promocionId = promocionId; }

    public Plato toEntity() {
        Plato p = new Plato();
        p.setId(this.id);
        p.setNombre(this.nombre);
        p.setDescripcion(this.descripcion);
        p.setPrecio(this.precio);
        p.setCategoria(this.categoria);
        p.setDisponible(this.disponible);
        p.setTiempoPreparacion(this.tiempoPreparacion);
        p.setProductoId(this.productoId);
        p.setPromocionId(this.promocionId);
        return p;
    }

    public static PlatoDTO fromEntity(Plato p) {
        if (p == null) return null;
        PlatoDTO dto = new PlatoDTO(p.getId(), p.getNombre(), p.getDescripcion(), p.getPrecio(), p.getCategoria(), p.isDisponible(), p.getTiempoPreparacion());
        dto.setProductoId(p.getProductoId());
        dto.setPromocionId(p.getPromocionId());
        return dto;
    }
}
