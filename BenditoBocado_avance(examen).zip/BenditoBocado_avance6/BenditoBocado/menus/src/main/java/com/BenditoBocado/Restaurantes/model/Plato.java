package com.BenditoBocado.Restaurantes.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

@Entity
@Table(name = "platos")
public class Plato {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @NotBlank(message = "El nombre es obligatorio")
  @Column(nullable = false)
  private String nombre;

  @Size(max = 1000, message = "La descripción no puede exceder 1000 caracteres")
  @Column(length = 1000)
  private String descripcion;

  @NotNull(message = "El precio es obligatorio")
  @DecimalMin(value = "0.0", inclusive = true, message = "El precio debe ser mayor o igual a 0")
  @Column(nullable = false)
  private BigDecimal precio;

  @NotBlank(message = "La categoría es obligatoria")
  @Column(nullable = false)
  private String categoria;

  @Column(nullable = false)
  private boolean disponible;

  @Min(value = 0, message = "El tiempo de preparación debe ser >= 0")
  @Column(name = "tiempo_preparacion_minutos", nullable = false)
  private int tiempoPreparacion;

  // FK logica (sin @ManyToOne, cada microservicio tiene su propia BD) hacia
  // el producto de "stock" del que depende este plato (control de existencias).
  @Column(name = "producto_id")
  private Integer productoId;

  // FK logica hacia la promocion activa aplicada a este plato, si tiene.
  @Column(name = "promocion_id")
  private Integer promocionId;

  public Plato() {}

  public Plato(Integer id, String nombre, String descripcion, BigDecimal precio,
               String categoria, boolean disponible, int tiempoPreparacion) {
    this.id = id;
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.precio = precio;
    this.categoria = categoria;
    this.disponible = disponible;
    this.tiempoPreparacion = tiempoPreparacion;
  }

  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }

  public String getNombre() { return nombre; }
  public void setNombre(String nombre) { this.nombre = nombre; }

  public String getDescripcion() { return descripcion; }
  public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

  public BigDecimal getPrecio() { return precio; }
  public void setPrecio(BigDecimal precio) { this.precio = precio; }

  public String getCategoria() { return categoria; }
  public void setCategoria(String categoria) { this.categoria = categoria; }

  public boolean isDisponible() { return disponible; }
  public void setDisponible(boolean disponible) { this.disponible = disponible; }

  public int getTiempoPreparacion() { return tiempoPreparacion; }
  public void setTiempoPreparacion(int tiempoPreparacion) { this.tiempoPreparacion = tiempoPreparacion; }

  public Integer getProductoId() { return productoId; }
  public void setProductoId(Integer productoId) { this.productoId = productoId; }

  public Integer getPromocionId() { return promocionId; }
  public void setPromocionId(Integer promocionId) { this.promocionId = promocionId; }

}
