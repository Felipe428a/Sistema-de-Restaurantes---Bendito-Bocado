package com.BenditoBocado.Restaurantes.client;

import com.BenditoBocado.Restaurantes.dto.PromocionRemotaDTO;
import org.springframework.stereotype.Component;

@Component
public class PromocionesClientFallback implements PromocionesClient {

    @Override
    public PromocionRemotaDTO obtenerPromocion(int id) {
        return null;
    }
}
