package com.BenditoBocado.Restaurantes.dto;

public class CategoriaDTO {
    private int id;
    private String nombre;
    private String tipo;
    private String descripcion;
    private String origen;
    private String estado;
    private int platosDisponibles;

    // getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getOrigen() { return origen; }
    public void setOrigen(String origen) { this.origen = origen; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public int getPlatosDisponibles() { return platosDisponibles; }
    public void setPlatosDisponibles(int v) { this.platosDisponibles = v; }
}