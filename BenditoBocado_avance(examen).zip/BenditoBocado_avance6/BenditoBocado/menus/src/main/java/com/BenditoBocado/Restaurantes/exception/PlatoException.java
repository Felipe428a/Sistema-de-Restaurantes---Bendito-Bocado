package com.BenditoBocado.Restaurantes.exception;

public class PlatoException extends RuntimeException {
    
    public PlatoException(String mensaje) {
        super(mensaje);
    }
    
    public PlatoException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
