package com.BenditoBocado.Restaurantes.client;

import com.BenditoBocado.Restaurantes.dto.CategoriaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * Cliente Feign hacia el microservicio "categorias", resuelto por nombre
 * a traves de Eureka (spring.application.name=categorias) en lugar de una
 * URL fija a localhost:8084.
 */
@FeignClient(name = "categorias")
public interface CategoriasClient {

    @GetMapping("/api/v1/categorias/simple")
    List<CategoriaDTO> obtenerCategoriasSimple();
}
