package com.BenditoBocado.Restaurantes.client;

import com.BenditoBocado.Restaurantes.dto.ProductoRemotoDTO;
import org.springframework.stereotype.Component;

// Si "stock" no responde (caido o timeout), no lanzamos 500: devolvemos
// null y el PlatoService decide un comportamiento por defecto (no bloquear
// la operacion sobre el plato solo porque stock esta caido).
@Component
public class StockClientFallback implements StockClient {

    @Override
    public ProductoRemotoDTO obtenerProducto(int id) {
        return null;
    }
}
