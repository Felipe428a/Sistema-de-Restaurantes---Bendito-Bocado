package com.BenditoBocado.Restaurantes.dto;

// Representa el Producto del microservicio "stock", tal como lo consume
// "menus" via Feign para el control de existencias de un plato.
public class ProductoRemotoDTO {
    private int id;
    private String nombre;
    private String estado;
    private int cantidadDisponible;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public int getCantidadDisponible() { return cantidadDisponible; }
    public void setCantidadDisponible(int cantidadDisponible) { this.cantidadDisponible = cantidadDisponible; }
}
