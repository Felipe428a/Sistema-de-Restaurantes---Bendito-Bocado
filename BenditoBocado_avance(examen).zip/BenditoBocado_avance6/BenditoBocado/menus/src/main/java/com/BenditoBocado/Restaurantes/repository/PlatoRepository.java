package com.BenditoBocado.Restaurantes.repository;

import com.BenditoBocado.Restaurantes.model.Plato;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlatoRepository extends JpaRepository<Plato, Integer> {

}
