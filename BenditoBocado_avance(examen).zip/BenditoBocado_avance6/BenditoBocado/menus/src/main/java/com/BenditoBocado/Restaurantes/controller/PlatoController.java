package com.BenditoBocado.Restaurantes.controller;

import com.BenditoBocado.Restaurantes.dto.CategoriaDTO;
import com.BenditoBocado.Restaurantes.dto.PlatoDTO;
import com.BenditoBocado.Restaurantes.model.Plato;
import com.BenditoBocado.Restaurantes.service.PlatoService;
import com.BenditoBocado.Restaurantes.service.RemoteConsumerService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/platos")
public class PlatoController {

  private final PlatoService platoService;
  private final RemoteConsumerService remoteConsumer;

  public PlatoController(PlatoService platoService, RemoteConsumerService remoteConsumer) {
    this.platoService = platoService;
    this.remoteConsumer = remoteConsumer;
  }

  @GetMapping
  public ResponseEntity<List<PlatoDTO>> obtenerPlatos() {
    List<PlatoDTO> dtos = platoService.listarPlatos().stream().map(PlatoDTO::fromEntity).collect(Collectors.toList());
    return ResponseEntity.ok(dtos);
  }

  @GetMapping("/{id}")
  public ResponseEntity<PlatoDTO> obtenerPorId(@PathVariable Integer id) {
    return platoService.obtenerPorId(id)
      .map(PlatoDTO::fromEntity)
      .map(ResponseEntity::ok)
      .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
  }

  @PostMapping
  public ResponseEntity<PlatoDTO> crearPlato(@Valid @RequestBody PlatoDTO platoDto) {
    Plato creado = platoService.agregarPlato(platoDto.toEntity());
    return ResponseEntity.status(HttpStatus.CREATED).body(PlatoDTO.fromEntity(creado));
  }

  @PutMapping("/{id}")
  public ResponseEntity<PlatoDTO> actualizarPlato(@PathVariable Integer id, @Valid @RequestBody PlatoDTO platoDto) {
    return platoService.actualizarPlato(id, platoDto.toEntity())
      .map(PlatoDTO::fromEntity)
      .map(ResponseEntity::ok)
      .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<?> borrarPlato(@PathVariable Integer id) {
    if (platoService.eliminarPlato(id)) {
      return ResponseEntity.noContent().build();
    }
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Plato no encontrado");
  }

  // Consumer endpoint: obtiene categorias desde otro servicio REST directo (sin mensajería)
  @GetMapping("/categorias-remote")
  public ResponseEntity<List<CategoriaDTO>> obtenerCategoriasRemotas() {
    return ResponseEntity.ok(remoteConsumer.fetchCategorias());
  }


}
