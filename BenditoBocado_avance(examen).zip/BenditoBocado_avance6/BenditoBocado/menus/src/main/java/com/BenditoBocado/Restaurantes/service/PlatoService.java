package com.BenditoBocado.Restaurantes.service;

import com.BenditoBocado.Restaurantes.client.PromocionesClient;
import com.BenditoBocado.Restaurantes.client.StockClient;
import com.BenditoBocado.Restaurantes.dto.ProductoRemotoDTO;
import com.BenditoBocado.Restaurantes.dto.PromocionRemotaDTO;
import com.BenditoBocado.Restaurantes.exception.PlatoException;
import com.BenditoBocado.Restaurantes.model.Plato;
import com.BenditoBocado.Restaurantes.repository.PlatoRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class PlatoService {

  private final PlatoRepository platoRepository;
  private final StockClient stockClient;
  private final PromocionesClient promocionesClient;

  public PlatoService(PlatoRepository platoRepository, StockClient stockClient,
                       PromocionesClient promocionesClient) {
    this.platoRepository = platoRepository;
    this.stockClient = stockClient;
    this.promocionesClient = promocionesClient;
  }

  public List<Plato> listarPlatos() {
    return platoRepository.findAll();
  }

  public Optional<Plato> obtenerPorId(Integer id) {
    return platoRepository.findById(id);
  }

  public Plato agregarPlato(Plato plato) {
    aplicarControlDeExistencias(plato);
    aplicarPromocionSiCorresponde(plato);
    return platoRepository.save(plato);
  }

  public Optional<Plato> actualizarPlato(Integer id, Plato datos) {
    return platoRepository.findById(id).map(existing -> {
      existing.setNombre(datos.getNombre());
      existing.setDescripcion(datos.getDescripcion());
      existing.setPrecio(datos.getPrecio());
      existing.setCategoria(datos.getCategoria());
      existing.setDisponible(datos.isDisponible());
      existing.setTiempoPreparacion(datos.getTiempoPreparacion());
      existing.setProductoId(datos.getProductoId());
      existing.setPromocionId(datos.getPromocionId());
      aplicarControlDeExistencias(existing);
      aplicarPromocionSiCorresponde(existing);
      return platoRepository.save(existing);
    });
  }

  // "Control de Existencias": si el plato depende de un producto de stock,
  // se consulta a "stock" (via Feign) y si no hay cantidad disponible, el
  // plato se marca automaticamente como no disponible.
  private void aplicarControlDeExistencias(Plato plato) {
    if (plato.getProductoId() == null) {
      return;
    }
    ProductoRemotoDTO producto = stockClient.obtenerProducto(plato.getProductoId());
    if (producto == null) {
      // stock no respondio (fallback): no bloqueamos la operacion, se
      // conserva el valor de "disponible" que trae el propio plato.
      return;
    }
    if (producto.getCantidadDisponible() <= 0) {
      plato.setDisponible(false);
    }
  }

  // Si el plato referencia una promocion, se valida contra "promociones"
  // (via Feign) que exista y este vigente; si no lo esta, se rechaza.
  private void aplicarPromocionSiCorresponde(Plato plato) {
    if (plato.getPromocionId() == null) {
      return;
    }
    PromocionRemotaDTO promocion = promocionesClient.obtenerPromocion(plato.getPromocionId());
    if (promocion == null) {
      // promociones no respondio (fallback): se deja la referencia tal cual,
      // sin bloquear la creacion/actualizacion del plato.
      return;
    }
    if (!promocion.estaActiva()) {
      throw new PlatoException("La promoción " + plato.getPromocionId() + " no está vigente");
    }
  }

  public boolean eliminarPlato(Integer id) {
    if (platoRepository.existsById(id)) {
      platoRepository.deleteById(id);
      return true;
    }
    return false;
  }

  public boolean datosValidos(Plato plato) {
    if (plato == null) return false;
    if (plato.getNombre() == null || plato.getNombre().isBlank()) return false;
    if (plato.getPrecio() == null) return false;
    if (plato.getPrecio().compareTo(BigDecimal.ZERO) < 0) return false;
    if (plato.getCategoria() == null || plato.getCategoria().isBlank()) return false;
    if (plato.getTiempoPreparacion() < 0) return false;
    return true;
  }

}
