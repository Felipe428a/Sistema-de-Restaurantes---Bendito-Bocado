package com.BenditoBocado.Restaurantes.service;

import com.BenditoBocado.Restaurantes.client.CategoriasClient;
import com.BenditoBocado.Restaurantes.dto.CategoriaDTO;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

/**
 * Antes llamaba a Categorias por RestTemplate + URL fija (app.categorias.url).
 * Ahora usa un cliente Feign que resuelve el servicio "categorias" via Eureka.
 */
@Service
public class RemoteConsumerService {

    private final CategoriasClient categoriasClient;

    public RemoteConsumerService(CategoriasClient categoriasClient) {
        this.categoriasClient = categoriasClient;
    }

    public List<CategoriaDTO> fetchCategorias() {
        try {
            List<CategoriaDTO> categorias = categoriasClient.obtenerCategoriasSimple();
            return categorias != null ? categorias : Collections.emptyList();
        } catch (Exception ex) {
            return Collections.emptyList();
        }
    }
}
