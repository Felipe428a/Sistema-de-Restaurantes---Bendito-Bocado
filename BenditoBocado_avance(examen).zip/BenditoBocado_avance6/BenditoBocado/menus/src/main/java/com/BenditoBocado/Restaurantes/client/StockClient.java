package com.BenditoBocado.Restaurantes.client;

import com.BenditoBocado.Restaurantes.config.FeignConfig;
import com.BenditoBocado.Restaurantes.dto.ProductoRemotoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// Cliente Feign hacia el microservicio "stock", resuelto por nombre a
// traves de Eureka. Usado para el "Control de Existencias" de un plato.
@FeignClient(name = "stock", configuration = FeignConfig.class, fallback = StockClientFallback.class)
public interface StockClient {

    @GetMapping("/api/v1/productos/{id}")
    ProductoRemotoDTO obtenerProducto(@PathVariable("id") int id);
}
