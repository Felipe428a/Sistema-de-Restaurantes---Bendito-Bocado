package com.BenditoBocado.Restaurantes.config;

import feign.Request;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

// Configuracion de timeouts para todos los FeignClient de este microservicio.
// Sin esto, un microservicio caido (categorias, stock, promociones) puede
// dejar a "menus" esperando indefinidamente una respuesta.
@Configuration
public class FeignConfig {

    @Bean
    public Request.Options requestOptions() {
        return new Request.Options(
                2000, TimeUnit.MILLISECONDS, // connectTimeout
                3000, TimeUnit.MILLISECONDS, // readTimeout
                true
        );
    }
}
