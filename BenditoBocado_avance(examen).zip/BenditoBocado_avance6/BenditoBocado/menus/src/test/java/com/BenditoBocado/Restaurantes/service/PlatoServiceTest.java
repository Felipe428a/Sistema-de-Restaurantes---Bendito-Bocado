package com.BenditoBocado.Restaurantes.service;

import com.BenditoBocado.Restaurantes.client.PromocionesClient;
import com.BenditoBocado.Restaurantes.client.StockClient;
import com.BenditoBocado.Restaurantes.dto.ProductoRemotoDTO;
import com.BenditoBocado.Restaurantes.dto.PromocionRemotaDTO;
import com.BenditoBocado.Restaurantes.exception.PlatoException;
import com.BenditoBocado.Restaurantes.model.Plato;
import com.BenditoBocado.Restaurantes.repository.PlatoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PlatoServiceTest {

    @Mock
    private PlatoRepository platoRepository;

    @Mock
    private StockClient stockClient;

    @Mock
    private PromocionesClient promocionesClient;

    @InjectMocks
    private PlatoService platoService;

    private Plato plato;

    @BeforeEach
    void setUp() {
        plato = new Plato(1, "Empanada de pino", "Empanada tradicional chilena",
                new BigDecimal("2500"), "Entrada", true, 15);
    }

    @Test
    void agregarPlato_sinProductoNiPromocion_guardaDirecto() {
        when(platoRepository.save(any(Plato.class))).thenReturn(plato);

        Plato guardado = platoService.agregarPlato(plato);

        assertNotNull(guardado);
        verify(stockClient, never()).obtenerProducto(any());
        verify(promocionesClient, never()).obtenerPromocion(any());
        verify(platoRepository).save(plato);
    }

    @Test
    void agregarPlato_conProductoSinStock_marcaNoDisponible() {
        plato.setProductoId(10);
        ProductoRemotoDTO producto = new ProductoRemotoDTO();
        producto.setId(10);
        producto.setCantidadDisponible(0);
        when(stockClient.obtenerProducto(10)).thenReturn(producto);
        when(platoRepository.save(any(Plato.class))).thenAnswer(inv -> inv.getArgument(0));

        Plato guardado = platoService.agregarPlato(plato);

        assertFalse(guardado.isDisponible());
        verify(stockClient).obtenerProducto(10);
    }

    @Test
    void agregarPlato_conProductoConStock_mantieneDisponible() {
        plato.setProductoId(10);
        ProductoRemotoDTO producto = new ProductoRemotoDTO();
        producto.setId(10);
        producto.setCantidadDisponible(5);
        when(stockClient.obtenerProducto(10)).thenReturn(producto);
        when(platoRepository.save(any(Plato.class))).thenAnswer(inv -> inv.getArgument(0));

        Plato guardado = platoService.agregarPlato(plato);

        assertTrue(guardado.isDisponible());
    }

    @Test
    void agregarPlato_stockNoResponde_noBloqueaLaOperacion() {
        plato.setProductoId(10);
        when(stockClient.obtenerProducto(10)).thenReturn(null); // fallback
        when(platoRepository.save(any(Plato.class))).thenAnswer(inv -> inv.getArgument(0));

        Plato guardado = platoService.agregarPlato(plato);

        assertTrue(guardado.isDisponible());
        verify(platoRepository).save(plato);
    }

    @Test
    void agregarPlato_conPromocionVencida_lanzaExcepcion() {
        plato.setPromocionId(99);
        PromocionRemotaDTO promocion = new PromocionRemotaDTO();
        promocion.setEstado("ACTIVA");
        promocion.setFechaInicio(LocalDate.now().minusDays(30));
        promocion.setFechaFin(LocalDate.now().minusDays(1)); // ya vencio
        when(promocionesClient.obtenerPromocion(99)).thenReturn(promocion);

        assertThrows(PlatoException.class, () -> platoService.agregarPlato(plato));
        verify(platoRepository, never()).save(any());
    }

    @Test
    void agregarPlato_conPromocionActiva_guardaOk() {
        plato.setPromocionId(99);
        PromocionRemotaDTO promocion = new PromocionRemotaDTO();
        promocion.setEstado("ACTIVA");
        promocion.setFechaInicio(LocalDate.now().minusDays(1));
        promocion.setFechaFin(LocalDate.now().plusDays(10));
        when(promocionesClient.obtenerPromocion(99)).thenReturn(promocion);
        when(platoRepository.save(any(Plato.class))).thenAnswer(inv -> inv.getArgument(0));

        Plato guardado = platoService.agregarPlato(plato);

        assertNotNull(guardado);
        verify(platoRepository).save(plato);
    }

    @Test
    void listarPlatos_deberiaRetornarTodos() {
        when(platoRepository.findAll()).thenReturn(List.of(plato));

        List<Plato> resultado = platoService.listarPlatos();

        assertEquals(1, resultado.size());
    }

    @Test
    void obtenerPorId_cuandoNoExiste_deberiaRetornarEmpty() {
        when(platoRepository.findById(999)).thenReturn(Optional.empty());

        Optional<Plato> resultado = platoService.obtenerPorId(999);

        assertTrue(resultado.isEmpty());
    }

    @Test
    void actualizarPlato_cuandoNoExiste_deberiaRetornarEmpty() {
        when(platoRepository.findById(999)).thenReturn(Optional.empty());

        Optional<Plato> resultado = platoService.actualizarPlato(999, plato);

        assertTrue(resultado.isEmpty());
        verify(platoRepository, never()).save(any());
    }
}
