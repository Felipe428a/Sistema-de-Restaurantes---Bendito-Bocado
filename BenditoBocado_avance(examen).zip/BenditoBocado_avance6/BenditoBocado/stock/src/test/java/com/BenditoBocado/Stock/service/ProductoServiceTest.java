package com.BenditoBocado.Stock.service;

import com.BenditoBocado.Stock.model.Producto;
import com.BenditoBocado.Stock.repository.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @InjectMocks
    private ProductoService productoService;

    private Producto producto;

    @BeforeEach
    void setUp() {
        producto = new Producto(1, "Harina", "Insumo", LocalDate.now(),
                "Molinos del Sur", "Abarrotes", "ACTIVO", 50);
    }

    @Test
    void listarProductos_deberiaRetornarTodos() {
        when(productoRepository.findAll()).thenReturn(List.of(producto));

        List<Producto> resultado = productoService.listarProductos();

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorId_cuandoExiste_deberiaRetornarlo() {
        when(productoRepository.findById(1)).thenReturn(Optional.of(producto));

        Optional<Producto> resultado = productoService.buscarPorId(1);

        assertTrue(resultado.isPresent());
        assertEquals(50, resultado.get().getCantidadDisponible());
    }

    @Test
    void buscarPorId_cuandoNoExiste_deberiaRetornarEmpty() {
        when(productoRepository.findById(99)).thenReturn(Optional.empty());

        Optional<Producto> resultado = productoService.buscarPorId(99);

        assertTrue(resultado.isEmpty());
    }

    @Test
    void agregarProducto_deberiaGuardarYRetornar() {
        when(productoRepository.save(any(Producto.class))).thenReturn(producto);

        Producto resultado = productoService.agregarProducto(producto);

        assertNotNull(resultado);
    }

    @Test
    void datosValidos_conDatosCompletos_deberiaRetornarTrue() {
        assertTrue(productoService.datosValidos(producto));
    }

    @Test
    void datosValidos_cantidadNegativa_deberiaRetornarFalse() {
        producto.setCantidadDisponible(-10);
        assertFalse(productoService.datosValidos(producto));
    }

    @Test
    void datosValidos_sinProveedor_deberiaRetornarFalse() {
        producto.setProveedor("");
        assertFalse(productoService.datosValidos(producto));
    }

    @Test
    void datosValidos_sinFechaIngreso_deberiaRetornarFalse() {
        producto.setFechaIngreso(null);
        assertFalse(productoService.datosValidos(producto));
    }
}
