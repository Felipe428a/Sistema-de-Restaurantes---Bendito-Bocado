package com.BenditoBocado.Stock.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "productos")
public class Producto {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;

  @Column(nullable = false)
  private String nombre;

  @Column(nullable = false)
  private String tipo;

  @Column(nullable = false)
  private LocalDate fechaIngreso;

  @Column(nullable = false)
  private String proveedor;

  @Column(nullable = false)
  private String categoria;

  @Column(nullable = false)
  private String estado;

  @Column(nullable = false)
  private int cantidadDisponible;

  public Producto() {
  }

  public Producto(int id, String nombre, String tipo, LocalDate fechaIngreso,
          String proveedor, String categoria,
          String estado, int cantidadDisponible) {
    this.id = id;
    this.nombre = nombre;
    this.tipo = tipo;
    this.fechaIngreso = fechaIngreso;
    this.proveedor = proveedor;
    this.categoria = categoria;
    this.estado = estado;
    this.cantidadDisponible = cantidadDisponible;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public LocalDate getFechaIngreso() {
    return fechaIngreso;
  }

  public void setFechaIngreso(LocalDate fechaIngreso) {
    this.fechaIngreso = fechaIngreso;
  }

  public String getProveedor() {
    return proveedor;
  }

  public void setProveedor(String proveedor) {
    this.proveedor = proveedor;
  }

  public String getCategoria() {
    return categoria;
  }

  public void setCategoria(String categoria) {
    this.categoria = categoria;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }

  public int getCantidadDisponible() {
    return cantidadDisponible;
  }

  public void setCantidadDisponible(int cantidadDisponible) {
    this.cantidadDisponible = cantidadDisponible;
  }
}
