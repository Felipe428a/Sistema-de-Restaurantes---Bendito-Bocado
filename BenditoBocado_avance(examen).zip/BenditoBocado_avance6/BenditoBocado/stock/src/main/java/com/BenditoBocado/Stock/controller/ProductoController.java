package com.BenditoBocado.Stock.controller;

import com.BenditoBocado.Stock.dto.ProductoRequestDTO;
import com.BenditoBocado.Stock.model.Producto;
import com.BenditoBocado.Stock.service.ProductoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/productos")
public class ProductoController {

  private final ProductoService productoService;

  public ProductoController(ProductoService productoService) {
    this.productoService = productoService;
  }

  @GetMapping
  public ResponseEntity<List<Producto>> obtenerProductos() {
    return ResponseEntity.ok(productoService.listarProductos());
  }

  @GetMapping("/{id}")
  public ResponseEntity<Producto> obtenerProducto(@PathVariable int id) {
    return productoService.buscarPorId(id)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.notFound().build());
  }

  @PostMapping
  public ResponseEntity<Producto> crearProducto(@Valid @RequestBody ProductoRequestDTO productoRequestDTO) {
    Producto producto = new Producto();
    producto.setNombre(productoRequestDTO.getNombre());
    producto.setTipo(productoRequestDTO.getTipo());
    producto.setFechaIngreso(productoRequestDTO.getFechaIngreso());
    producto.setProveedor(productoRequestDTO.getProveedor());
    producto.setCategoria(productoRequestDTO.getCategoria());
    producto.setEstado(productoRequestDTO.getEstado());
    producto.setCantidadDisponible(productoRequestDTO.getCantidadDisponible());

    Producto nuevoProducto = productoService.agregarProducto(producto);
    return ResponseEntity.status(HttpStatus.CREATED).body(nuevoProducto);
  }
}
