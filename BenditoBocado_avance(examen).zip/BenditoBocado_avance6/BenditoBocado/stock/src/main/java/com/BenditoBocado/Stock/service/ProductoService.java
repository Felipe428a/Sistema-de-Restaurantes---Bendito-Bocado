package com.BenditoBocado.Stock.service;

import com.BenditoBocado.Stock.model.Producto;
import com.BenditoBocado.Stock.repository.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoService {

  private final ProductoRepository productoRepository;

  public ProductoService(ProductoRepository productoRepository) {
    this.productoRepository = productoRepository;
  }

  public List<Producto> listarProductos() {
    return productoRepository.findAll();
  }

  // Usado por menus (Feign) para consultar existencias de un producto antes
  // de marcar un plato como disponible ("Control de Existencias" del diagrama).
  public Optional<Producto> buscarPorId(int id) {
    return productoRepository.findById(id);
  }

  public Producto agregarProducto(Producto producto) {
    return productoRepository.save(producto);
  }

  public boolean datosValidos(Producto producto) {
    if (producto.getNombre() == null || producto.getNombre().isBlank()) {
      return false;
    }

    if (producto.getTipo() == null || producto.getTipo().isBlank()) {
      return false;
    }

    if (producto.getFechaIngreso() == null) {
      return false;
    }

    if (producto.getProveedor() == null || producto.getProveedor().isBlank()) {
      return false;
    }

    if (producto.getCategoria() == null || producto.getCategoria().isBlank()) {
      return false;
    }

    if (producto.getEstado() == null || producto.getEstado().isBlank()) {
      return false;
    }

    if (producto.getCantidadDisponible() < 0) {
      return false;
    }

    return true;
  }
}
