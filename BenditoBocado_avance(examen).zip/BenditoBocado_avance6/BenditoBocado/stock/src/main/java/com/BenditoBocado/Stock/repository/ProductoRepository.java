package com.BenditoBocado.Stock.repository;

import com.BenditoBocado.Stock.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
}
