package com.BenditoBocado.Stock.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public class ProductoRequestDTO {

  @NotBlank(message = "El nombre del producto es obligatorio")
  private String nombre;

  @NotBlank(message = "El tipo de producto es obligatorio")
  private String tipo;

  @NotNull(message = "La fecha de ingreso es obligatoria")
  private LocalDate fechaIngreso;

  @NotBlank(message = "El proveedor es obligatorio")
  private String proveedor;

  @NotBlank(message = "La categoría es obligatoria")
  private String categoria;

  @NotBlank(message = "El estado es obligatorio")
  private String estado;

  @Min(value = 0, message = "La cantidad disponible no puede ser negativa")
  private int cantidadDisponible;

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public LocalDate getFechaIngreso() {
    return fechaIngreso;
  }

  public void setFechaIngreso(LocalDate fechaIngreso) {
    this.fechaIngreso = fechaIngreso;
  }

  public String getProveedor() {
    return proveedor;
  }

  public void setProveedor(String proveedor) {
    this.proveedor = proveedor;
  }

  public String getCategoria() {
    return categoria;
  }

  public void setCategoria(String categoria) {
    this.categoria = categoria;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }

  public int getCantidadDisponible() {
    return cantidadDisponible;
  }

  public void setCantidadDisponible(int cantidadDisponible) {
    this.cantidadDisponible = cantidadDisponible;
  }
}
