package com.BenditoBocado.Repartidores.service;

import com.BenditoBocado.Repartidores.client.DireccionesClient;
import com.BenditoBocado.Repartidores.dto.DireccionRemotaDTO;
import com.BenditoBocado.Repartidores.model.Repartidor;
import com.BenditoBocado.Repartidores.repository.RepartidorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RepartidorServiceImplTest {

    @Mock
    private RepartidorRepository repartidorRepository;

    @Mock
    private DireccionesClient direccionesClient;

    @InjectMocks
    private RepartidorServiceImpl repartidorService;

    private Repartidor repartidor;

    @BeforeEach
    void setUp() {
        repartidor = new Repartidor(1, "Pedro Soto", "+56911111111", "Norte", "ACTIVO", true, "Moto");
    }

    @Test
    void listarRepartidores_deberiaRetornarTodos() {
        when(repartidorRepository.findAll()).thenReturn(List.of(repartidor));

        List<Repartidor> resultado = repartidorService.listarRepartidores();

        assertEquals(1, resultado.size());
    }

    @Test
    void obtenerRepartidorPorId_cuandoNoExiste_deberiaRetornarNull() {
        when(repartidorRepository.findById(99)).thenReturn(Optional.empty());

        Repartidor resultado = repartidorService.obtenerRepartidorPorId(99);

        assertNull(resultado);
    }

    @Test
    void datosValidos_conDatosCompletos_deberiaRetornarTrue() {
        assertTrue(repartidorService.datosValidos(repartidor));
    }

    @Test
    void datosValidos_sinVehiculo_deberiaRetornarFalse() {
        repartidor.setVehiculo("");
        assertFalse(repartidorService.datosValidos(repartidor));
    }

    @Test
    void datosValidos_null_deberiaRetornarFalse() {
        assertFalse(repartidorService.datosValidos(null));
    }

    @Test
    void eliminarRepartidor_cuandoExiste_deberiaEliminarYRetornarTrue() {
        when(repartidorRepository.existsById(1)).thenReturn(true);

        boolean resultado = repartidorService.eliminarRepartidor(1);

        assertTrue(resultado);
        verify(repartidorRepository).deleteById(1);
    }

    @Test
    void eliminarRepartidor_cuandoNoExiste_deberiaRetornarFalse() {
        when(repartidorRepository.existsById(99)).thenReturn(false);

        boolean resultado = repartidorService.eliminarRepartidor(99);

        assertFalse(resultado);
        verify(repartidorRepository, never()).deleteById(anyInt());
    }

    @Test
    void asignarDireccion_repartidorNoExiste_deberiaRetornarNull() {
        when(repartidorRepository.findById(99)).thenReturn(Optional.empty());

        Repartidor resultado = repartidorService.asignarDireccion(99, 5);

        assertNull(resultado);
        verify(direccionesClient, never()).obtenerDireccion(anyInt());
    }

    @Test
    void asignarDireccion_direccionNoValida_deberiaLanzarExcepcion() {
        when(repartidorRepository.findById(1)).thenReturn(Optional.of(repartidor));
        when(direccionesClient.obtenerDireccion(5)).thenReturn(null); // fallback / no existe

        assertThrows(IllegalStateException.class, () -> repartidorService.asignarDireccion(1, 5));
        verify(repartidorRepository, never()).save(any());
    }

    @Test
    void asignarDireccion_direccionValida_deberiaAsignarYGuardar() {
        when(repartidorRepository.findById(1)).thenReturn(Optional.of(repartidor));
        DireccionRemotaDTO direccion = new DireccionRemotaDTO();
        direccion.setId(5);
        when(direccionesClient.obtenerDireccion(5)).thenReturn(direccion);
        when(repartidorRepository.save(any(Repartidor.class))).thenAnswer(inv -> inv.getArgument(0));

        Repartidor resultado = repartidorService.asignarDireccion(1, 5);

        assertNotNull(resultado);
        assertEquals(5, resultado.getDireccionId());
    }
}
