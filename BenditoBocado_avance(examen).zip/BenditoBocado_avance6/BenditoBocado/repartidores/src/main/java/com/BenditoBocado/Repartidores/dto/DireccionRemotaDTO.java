package com.BenditoBocado.Repartidores.dto;

// Representa la Direccion del microservicio "direcciones", tal como la
// consume "repartidores" via Feign al asignar una direccion de entrega.
public class DireccionRemotaDTO {
    private int id;
    private String calle;
    private String numero;
    private String ciudad;
    private String region;
    private String codigoPostal;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCalle() { return calle; }
    public void setCalle(String calle) { this.calle = calle; }
    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }
    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }
    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }
    public String getCodigoPostal() { return codigoPostal; }
    public void setCodigoPostal(String codigoPostal) { this.codigoPostal = codigoPostal; }
}
