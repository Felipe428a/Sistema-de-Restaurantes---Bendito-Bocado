package com.BenditoBocado.Repartidores.repository;

import com.BenditoBocado.Repartidores.model.Repartidor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepartidorRepository extends JpaRepository<Repartidor, Integer> {

}
