package com.BenditoBocado.Repartidores.model;

import jakarta.persistence.*;

@Entity
@Table(name = "repartidores")
public class Repartidor {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;

  @Column(nullable = false)
  private String nombre;

  @Column(nullable = false)
  private String telefono;

  @Column(nullable = false)
  private String zona;

  @Column(nullable = false)
  private String estado;

  @Column(nullable = false)
  private boolean disponibilidad;

  @Column(nullable = false)
  private String vehiculo;

  // FK logica hacia la direccion de entrega actualmente asignada (microservicio "direcciones").
  @Column(name = "direccion_id")
  private Integer direccionId;

  public Repartidor() {
  }

  public Repartidor(int id, String nombre, String telefono, String zona, String estado, boolean disponibilidad, String vehiculo) {
    this.id = id;
    this.nombre = nombre;
    this.telefono = telefono;
    this.zona = zona;
    this.estado = estado;
    this.disponibilidad = disponibilidad;
    this.vehiculo = vehiculo;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getTelefono() {
    return telefono;
  }

  public void setTelefono(String telefono) {
    this.telefono = telefono;
  }

  public String getZona() {
    return zona;
  }

  public void setZona(String zona) {
    this.zona = zona;
  }

  public String getEstado() {
    return estado;
  }

  public void setEstado(String estado) {
    this.estado = estado;
  }

  public boolean isDisponibilidad() {
    return disponibilidad;
  }

  public void setDisponibilidad(boolean disponibilidad) {
    this.disponibilidad = disponibilidad;
  }

  public String getVehiculo() {
    return vehiculo;
  }

  public void setVehiculo(String vehiculo) {
    this.vehiculo = vehiculo;
  }

  public Integer getDireccionId() {
    return direccionId;
  }

  public void setDireccionId(Integer direccionId) {
    this.direccionId = direccionId;
  }

}
