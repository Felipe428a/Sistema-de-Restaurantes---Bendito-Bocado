package com.BenditoBocado.Repartidores.service;

import com.BenditoBocado.Repartidores.client.DireccionesClient;
import com.BenditoBocado.Repartidores.dto.DireccionRemotaDTO;
import com.BenditoBocado.Repartidores.model.Repartidor;
import com.BenditoBocado.Repartidores.repository.RepartidorRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class RepartidorServiceImpl implements RepartidorService {

    private final RepartidorRepository repartidorRepository;
    private final DireccionesClient direccionesClient;

    public RepartidorServiceImpl(RepartidorRepository repartidorRepository, DireccionesClient direccionesClient) {
        this.repartidorRepository = repartidorRepository;
        this.direccionesClient = direccionesClient;
    }

    @Override
    public List<Repartidor> listarRepartidores() {
        return repartidorRepository.findAll();
    }

    @Override
    public Repartidor obtenerRepartidorPorId(int id) {
        Optional<Repartidor> repartidor = repartidorRepository.findById(id);
        return repartidor.orElse(null);
    }

    @Override
    public Repartidor agregarRepartidor(Repartidor repartidor) {
        return repartidorRepository.save(repartidor);
    }

    @Override
    public Repartidor actualizarRepartidor(int id, Repartidor repartidorActualizado) {
        Optional<Repartidor> repartidorExistente = repartidorRepository.findById(id);
        
        if (repartidorExistente.isPresent()) {
            Repartidor repartidor = repartidorExistente.get();
            repartidor.setNombre(repartidorActualizado.getNombre());
            repartidor.setTelefono(repartidorActualizado.getTelefono());
            repartidor.setZona(repartidorActualizado.getZona());
            repartidor.setEstado(repartidorActualizado.getEstado());
            repartidor.setDisponibilidad(repartidorActualizado.isDisponibilidad());
            repartidor.setVehiculo(repartidorActualizado.getVehiculo());
            return repartidorRepository.save(repartidor);
        }
        
        return null;
    }

    @Override
    public boolean eliminarRepartidor(int id) {
        if (repartidorRepository.existsById(id)) {
            repartidorRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public boolean datosValidos(Repartidor repartidor) {
        return repartidor != null &&
                repartidor.getNombre() != null && !repartidor.getNombre().isEmpty() &&
                repartidor.getTelefono() != null && !repartidor.getTelefono().isEmpty() &&
                repartidor.getZona() != null && !repartidor.getZona().isEmpty() &&
                repartidor.getEstado() != null && !repartidor.getEstado().isEmpty() &&
                repartidor.getVehiculo() != null && !repartidor.getVehiculo().isEmpty();
    }

    @Override
    public Repartidor asignarDireccion(int id, int direccionId) {
        Optional<Repartidor> repartidorExistente = repartidorRepository.findById(id);
        if (repartidorExistente.isEmpty()) {
            return null;
        }

        DireccionRemotaDTO direccion = direccionesClient.obtenerDireccion(direccionId);
        if (direccion == null) {
            throw new IllegalStateException(
                    "No se pudo validar la dirección " + direccionId + " (servicio direcciones no disponible o dirección inexistente)");
        }

        Repartidor repartidor = repartidorExistente.get();
        repartidor.setDireccionId(direccionId);
        return repartidorRepository.save(repartidor);
    }
}
