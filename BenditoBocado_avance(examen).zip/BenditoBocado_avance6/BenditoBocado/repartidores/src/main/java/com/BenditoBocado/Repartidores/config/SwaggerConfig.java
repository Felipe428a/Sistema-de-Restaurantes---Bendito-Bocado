package com.BenditoBocado.Repartidores.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

// Expone la documentacion OpenAPI/Swagger de este microservicio en:
//   http://localhost:8088/swagger-ui.html
//   http://localhost:8088/v3/api-docs (JSON crudo, usado por el API Gateway para agregar todo)
@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI RepartidoresOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Repartidores API")
                        .description("Gestion de repartidores y asignacion de direcciones de entrega")
                        .version("1.0.0")
                        .contact(new Contact().name("BenditoBocado Team")))
                .servers(List.of(
                        new Server().url("http://localhost:8088").description("Directo al microservicio"),
                        new Server().url("http://localhost:8070").description("A traves del API Gateway")
                ));
    }
}
