package com.BenditoBocado.Repartidores.controller;

import com.BenditoBocado.Repartidores.model.Repartidor;
import com.BenditoBocado.Repartidores.service.RepartidorService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/repartidores")
public class RepartidorController {

  private final RepartidorService repartidorService;

  public RepartidorController(RepartidorService repartidorService) {
    this.repartidorService = repartidorService;
  }

  @GetMapping
  public ResponseEntity<List<Repartidor>> obtenerRepartidores() {
    return ResponseEntity.ok(repartidorService.listarRepartidores());
  }

  @PostMapping
  public ResponseEntity<?> crearRepartidor(@RequestBody Repartidor repartidor) {
    if (!repartidorService.datosValidos(repartidor)) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Datos de repartidor inválidos");
    }

    Repartidor nuevo = repartidorService.agregarRepartidor(repartidor);
    return ResponseEntity.status(HttpStatus.CREATED).body(nuevo);
  }

  @GetMapping("/{id}")
  public ResponseEntity<?> obtenerRepartidor(@PathVariable int id) {
    Repartidor repartidor = repartidorService.obtenerRepartidorPorId(id);
    if (repartidor == null) {
      return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Repartidor no encontrado");
    }
    return ResponseEntity.ok(repartidor);
  }

  @PutMapping("/{id}")
  public ResponseEntity<?> actualizarRepartidor(@PathVariable int id, @RequestBody Repartidor repartidor) {
    if (!repartidorService.datosValidos(repartidor)) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Datos de repartidor inválidos");
    }

    Repartidor actualizado = repartidorService.actualizarRepartidor(id, repartidor);
    if (actualizado == null) {
      return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Repartidor no encontrado");
    }
    return ResponseEntity.ok(actualizado);
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<?> eliminarRepartidor(@PathVariable int id) {
    boolean eliminado = repartidorService.eliminarRepartidor(id);
    if (!eliminado) {
      return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Repartidor no encontrado");
    }
    return ResponseEntity.noContent().build();
  }

  @PutMapping("/{id}/direccion/{direccionId}")
  public ResponseEntity<?> asignarDireccion(@PathVariable int id, @PathVariable int direccionId) {
    try {
      Repartidor actualizado = repartidorService.asignarDireccion(id, direccionId);
      if (actualizado == null) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Repartidor no encontrado");
      }
      return ResponseEntity.ok(actualizado);
    } catch (IllegalStateException e) {
      return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
    }
  }

}
