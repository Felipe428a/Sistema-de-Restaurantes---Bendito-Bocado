package com.BenditoBocado.Repartidores.service;

import com.BenditoBocado.Repartidores.model.Repartidor;
import java.util.List;

public interface RepartidorService {
    List<Repartidor> listarRepartidores();
    Repartidor obtenerRepartidorPorId(int id);
    Repartidor agregarRepartidor(Repartidor repartidor);
    Repartidor actualizarRepartidor(int id, Repartidor repartidor);
    boolean eliminarRepartidor(int id);
    boolean datosValidos(Repartidor repartidor);

    // Repartidores <-> Direcciones: valida contra "direcciones" (via Feign)
    // que la direccion exista y la asigna al repartidor.
    Repartidor asignarDireccion(int id, int direccionId);
}
