package com.BenditoBocado.Repartidores.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public class RepartidorRequestDTO {

    @NotBlank(message = "El nombre del repartidor es obligatorio")
    private String nombre;

    @NotBlank(message = "El teléfono es obligatorio")
    @Pattern(regexp = "^[0-9]{7,}$", message = "El teléfono debe contener solo dígitos y tener al menos 7 caracteres")
    private String telefono;

    private boolean disponibilidad;

    @NotBlank(message = "El tipo de vehículo es obligatorio")
    private String vehiculo;

    public RepartidorRequestDTO() {
    }

    public RepartidorRequestDTO(String nombre, String telefono, boolean disponibilidad, String vehiculo) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.disponibilidad = disponibilidad;
        this.vehiculo = vehiculo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public boolean isDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(boolean disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public String getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(String vehiculo) {
        this.vehiculo = vehiculo;
    }
}
