package com.BenditoBocado.Repartidores.client;

import com.BenditoBocado.Repartidores.config.FeignConfig;
import com.BenditoBocado.Repartidores.dto.DireccionRemotaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// Cliente Feign hacia el microservicio "direcciones", resuelto por nombre
// a traves de Eureka. Usado para validar la direccion de entrega asignada
// a un repartidor.
@FeignClient(name = "direcciones", configuration = FeignConfig.class, fallback = DireccionesClientFallback.class)
public interface DireccionesClient {

    @GetMapping("/api/v1/direcciones/{id}")
    DireccionRemotaDTO obtenerDireccion(@PathVariable("id") int id);
}
