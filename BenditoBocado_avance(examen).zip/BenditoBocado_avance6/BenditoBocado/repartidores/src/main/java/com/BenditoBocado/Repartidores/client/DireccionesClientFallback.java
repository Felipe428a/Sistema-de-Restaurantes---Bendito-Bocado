package com.BenditoBocado.Repartidores.client;

import com.BenditoBocado.Repartidores.dto.DireccionRemotaDTO;
import org.springframework.stereotype.Component;

@Component
public class DireccionesClientFallback implements DireccionesClient {

    @Override
    public DireccionRemotaDTO obtenerDireccion(int id) {
        return null;
    }
}
