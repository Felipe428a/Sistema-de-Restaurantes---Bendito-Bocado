package com.BenditoBocado.Pagos.service;

import com.BenditoBocado.Pagos.client.PedidosClient;
import com.BenditoBocado.Pagos.client.PromocionesClient;
import com.BenditoBocado.Pagos.dto.PedidoRemotoDTO;
import com.BenditoBocado.Pagos.dto.PromocionRemotaDTO;
import com.BenditoBocado.Pagos.exception.PagoException;
import com.BenditoBocado.Pagos.model.Pago;
import com.BenditoBocado.Pagos.repository.PagoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PagoServiceTest {

    @Mock
    private PagoRepository pagoRepository;

    @Mock
    private PedidosClient pedidosClient;

    @Mock
    private PromocionesClient promocionesClient;

    @InjectMocks
    private PagoService pagoService;

    private Pago pago;

    @BeforeEach
    void setUp() {
        pago = new Pago(1, "Mesa 4", "Ana", LocalDate.now(), new BigDecimal("15000"), "EFECTIVO", "PENDIENTE");
    }

    @Test
    void agregarPago_sinPedidoNiPromocion_guardaDirecto() {
        when(pagoRepository.save(any(Pago.class))).thenReturn(pago);

        Pago guardado = pagoService.agregarPago(pago);

        assertNotNull(guardado);
        verify(pedidosClient, never()).obtenerPedido(any());
        verify(promocionesClient, never()).obtenerPromocion(anyInt());
        verify(pedidosClient, never()).vincularPago(any(), any());
    }

    @Test
    void agregarPago_conPedidoValido_vinculaElPagoAlPedido() {
        pago.setPedidoId(50);
        PedidoRemotoDTO pedidoRemoto = new PedidoRemotoDTO();
        pedidoRemoto.setId(50);
        pedidoRemoto.setEstado("PENDIENTE");
        when(pedidosClient.obtenerPedido(50)).thenReturn(pedidoRemoto);
        when(pagoRepository.save(any(Pago.class))).thenReturn(pago);

        Pago guardado = pagoService.agregarPago(pago);

        assertNotNull(guardado);
        verify(pedidosClient).vincularPago(50, pago.getId());
    }

    @Test
    void agregarPago_pedidosNoResponde_noBloqueaElPago() {
        pago.setPedidoId(50);
        when(pedidosClient.obtenerPedido(50)).thenReturn(null); // fallback
        when(pagoRepository.save(any(Pago.class))).thenReturn(pago);

        Pago guardado = pagoService.agregarPago(pago);

        assertNotNull(guardado);
    }

    @Test
    void agregarPago_conPromocionVigente_seGuardaOk() {
        pago.setPromocionId(7);
        PromocionRemotaDTO promo = new PromocionRemotaDTO();
        promo.setEstado("ACTIVA");
        promo.setCuposDisponibles(5);
        promo.setFechaInicio(LocalDate.now().minusDays(1));
        promo.setFechaFin(LocalDate.now().plusDays(5));
        when(promocionesClient.obtenerPromocion(7)).thenReturn(promo);
        when(pagoRepository.save(any(Pago.class))).thenReturn(pago);

        Pago guardado = pagoService.agregarPago(pago);

        assertNotNull(guardado);
        verify(pagoRepository).save(pago);
    }

    @Test
    void agregarPago_conPromocionSinCupos_lanzaExcepcion() {
        pago.setPromocionId(7);
        PromocionRemotaDTO promo = new PromocionRemotaDTO();
        promo.setEstado("ACTIVA");
        promo.setCuposDisponibles(0);
        promo.setFechaInicio(LocalDate.now().minusDays(1));
        promo.setFechaFin(LocalDate.now().plusDays(5));
        when(promocionesClient.obtenerPromocion(7)).thenReturn(promo);

        assertThrows(PagoException.class, () -> pagoService.agregarPago(pago));
        verify(pagoRepository, never()).save(any());
    }

    @Test
    void listarPagos_deberiaRetornarTodos() {
        when(pagoRepository.findAll()).thenReturn(List.of(pago));

        List<Pago> resultado = pagoService.listarPagos();

        assertEquals(1, resultado.size());
    }
}
