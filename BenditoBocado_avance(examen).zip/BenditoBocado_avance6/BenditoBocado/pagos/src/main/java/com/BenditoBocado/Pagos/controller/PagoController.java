package com.BenditoBocado.Pagos.controller;

import com.BenditoBocado.Pagos.dto.PagoRequestDTO;
import com.BenditoBocado.Pagos.model.Pago;
import com.BenditoBocado.Pagos.service.PagoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/pagos")
public class PagoController {

    private final PagoService pagoService;

    public PagoController(PagoService pagoService) {
        this.pagoService = pagoService;
    }

    @GetMapping
    public ResponseEntity<List<Pago>> obtenerPagos() {
        return ResponseEntity.ok(pagoService.listarPagos());
    }

    @PostMapping
    public ResponseEntity<?> crearPago(@Valid @RequestBody PagoRequestDTO pagoDTO) {
        Pago pago = new Pago();
        pago.setNumeroMesa(pagoDTO.getNumeroMesa());
        pago.setMesero(pagoDTO.getMesero());
        pago.setFecha(pagoDTO.getFecha());
        pago.setTotal(pagoDTO.getTotal());
        pago.setMetodoPago(pagoDTO.getMetodoPago());
        pago.setEstado(pagoDTO.getEstado());
        pago.setPedidoId(pagoDTO.getPedidoId());
        pago.setPromocionId(pagoDTO.getPromocionId());

        Pago nuevoPago = pagoService.agregarPago(pago);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoPago);
    }
}
