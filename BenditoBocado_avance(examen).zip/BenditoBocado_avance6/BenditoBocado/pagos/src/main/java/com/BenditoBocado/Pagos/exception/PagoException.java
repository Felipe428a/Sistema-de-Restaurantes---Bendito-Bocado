package com.BenditoBocado.Pagos.exception;

public class PagoException extends RuntimeException {

    private String codigo;

    public PagoException(String mensaje) {
        super(mensaje);
        this.codigo = "ERROR_GENERAL";
    }

    public PagoException(String mensaje, String codigo) {
        super(mensaje);
        this.codigo = codigo;
    }

    public PagoException(String mensaje, Throwable causa) {
        super(mensaje, causa);
        this.codigo = "ERROR_GENERAL";
    }

    public PagoException(String mensaje, String codigo, Throwable causa) {
        super(mensaje, causa);
        this.codigo = codigo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}
