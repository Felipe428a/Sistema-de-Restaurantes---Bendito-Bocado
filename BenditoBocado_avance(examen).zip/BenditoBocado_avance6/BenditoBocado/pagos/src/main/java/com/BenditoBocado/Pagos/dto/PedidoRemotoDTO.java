package com.BenditoBocado.Pagos.dto;

// Representa el Pedido del microservicio "pedidos", tal como lo consume
// "pagos" via Feign para validar que el pedido exista antes de cobrarlo.
public class PedidoRemotoDTO {
    private Integer id;
    private String estado;
    private Double total;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }
}
