package com.BenditoBocado.Pagos.client;

import com.BenditoBocado.Pagos.dto.PedidoRemotoDTO;
import org.springframework.stereotype.Component;

@Component
public class PedidosClientFallback implements PedidosClient {

    @Override
    public PedidoRemotoDTO obtenerPedido(Integer id) {
        return null;
    }

    @Override
    public void vincularPago(Integer id, Integer pagoId) {
        // Si "pedidos" no responde, el pago igual se registra; el vinculo
        // inverso (pedido -> pago) queda pendiente de sincronizar despues.
    }
}
