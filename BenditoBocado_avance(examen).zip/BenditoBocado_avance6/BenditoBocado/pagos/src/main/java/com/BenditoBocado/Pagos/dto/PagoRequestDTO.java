package com.BenditoBocado.Pagos.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public class PagoRequestDTO {

    @NotBlank(message = "El número de mesa es obligatorio")
    private String numeroMesa;

    @NotBlank(message = "El nombre del mesero es obligatorio")
    private String mesero;

    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fecha;

    @NotNull(message = "El total es obligatorio")
    @DecimalMin(value = "0.01", message = "El total debe ser mayor que cero")
    private BigDecimal total;

    @NotBlank(message = "El método de pago es obligatorio")
    private String metodoPago;

    private String estado = "PENDIENTE";

    // Si se informa, "pagos" valida contra "pedidos" (Feign) que el pedido exista.
    private Integer pedidoId;

    // Si se informa, "pagos" valida contra "promociones" (Feign) que la promo este vigente.
    private Integer promocionId;

    public PagoRequestDTO() {
    }

    public PagoRequestDTO(String numeroMesa, String mesero, LocalDate fecha,
                          BigDecimal total, String metodoPago) {
        this.numeroMesa = numeroMesa;
        this.mesero = mesero;
        this.fecha = fecha;
        this.total = total;
        this.metodoPago = metodoPago;
    }

    public String getNumeroMesa() {
        return numeroMesa;
    }

    public void setNumeroMesa(String numeroMesa) {
        this.numeroMesa = numeroMesa;
    }

    public String getMesero() {
        return mesero;
    }

    public void setMesero(String mesero) {
        this.mesero = mesero;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Integer getPedidoId() {
        return pedidoId;
    }

    public void setPedidoId(Integer pedidoId) {
        this.pedidoId = pedidoId;
    }

    public Integer getPromocionId() {
        return promocionId;
    }

    public void setPromocionId(Integer promocionId) {
        this.promocionId = promocionId;
    }
}
