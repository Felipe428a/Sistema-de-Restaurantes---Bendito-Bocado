package com.BenditoBocado.Pagos.client;

import com.BenditoBocado.Pagos.dto.PromocionRemotaDTO;
import org.springframework.stereotype.Component;

@Component
public class PromocionesClientFallback implements PromocionesClient {

    @Override
    public PromocionRemotaDTO obtenerPromocion(int id) {
        return null;
    }
}
