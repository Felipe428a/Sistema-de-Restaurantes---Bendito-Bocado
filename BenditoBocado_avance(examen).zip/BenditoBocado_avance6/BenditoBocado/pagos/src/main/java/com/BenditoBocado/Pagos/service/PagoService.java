package com.BenditoBocado.Pagos.service;

import com.BenditoBocado.Pagos.client.PedidosClient;
import com.BenditoBocado.Pagos.client.PromocionesClient;
import com.BenditoBocado.Pagos.dto.PedidoRemotoDTO;
import com.BenditoBocado.Pagos.dto.PromocionRemotaDTO;
import com.BenditoBocado.Pagos.exception.PagoException;
import com.BenditoBocado.Pagos.model.Pago;
import com.BenditoBocado.Pagos.repository.PagoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PagoService {

    private final PagoRepository pagoRepository;
    private final PedidosClient pedidosClient;
    private final PromocionesClient promocionesClient;

    public PagoService(PagoRepository pagoRepository, PedidosClient pedidosClient,
                        PromocionesClient promocionesClient) {
        this.pagoRepository = pagoRepository;
        this.pedidosClient = pedidosClient;
        this.promocionesClient = promocionesClient;
    }

    public List<Pago> listarPagos() {
        return pagoRepository.findAll();
    }

    public Pago agregarPago(Pago pago) {
        validarPedidoSiCorresponde(pago);
        validarPromocionSiCorresponde(pago);

        Pago guardado = pagoRepository.save(pago);

        // Avisamos al pedido (si tiene) que ya tiene un pago vinculado.
        // Si "pedidos" no responde, el fallback no hace nada y no bloquea el pago.
        if (guardado.getPedidoId() != null) {
            pedidosClient.vincularPago(guardado.getPedidoId(), guardado.getId());
        }
        return guardado;
    }

    // Pedidos <-> Pagos: si el pago referencia un pedido, se valida contra
    // "pedidos" (via Feign) que exista antes de registrar el cobro.
    private void validarPedidoSiCorresponde(Pago pago) {
        if (pago.getPedidoId() == null) {
            return;
        }
        PedidoRemotoDTO pedido = pedidosClient.obtenerPedido(pago.getPedidoId());
        if (pedido == null) {
            // "pedidos" no respondio (fallback): no bloqueamos el pago, solo
            // queda sin la validacion cruzada por esta vez.
            return;
        }
    }

    // Pagos <-> Promociones: si el pago referencia una promocion, se valida
    // contra "promociones" (via Feign) que exista y este vigente.
    private void validarPromocionSiCorresponde(Pago pago) {
        if (pago.getPromocionId() == null) {
            return;
        }
        PromocionRemotaDTO promocion = promocionesClient.obtenerPromocion(pago.getPromocionId());
        if (promocion == null) {
            return;
        }
        if (!promocion.estaActiva()) {
            throw new PagoException("La promoción " + pago.getPromocionId() + " no está vigente");
        }
    }
}
