package com.BenditoBocado.Pagos.repository;

import com.BenditoBocado.Pagos.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagoRepository extends JpaRepository<Pago, Integer> {
}
