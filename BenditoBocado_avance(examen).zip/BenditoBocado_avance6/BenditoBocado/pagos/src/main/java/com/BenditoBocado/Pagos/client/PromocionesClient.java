package com.BenditoBocado.Pagos.client;

import com.BenditoBocado.Pagos.config.FeignConfig;
import com.BenditoBocado.Pagos.dto.PromocionRemotaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// Cliente Feign hacia el microservicio "promociones", resuelto por nombre
// a traves de Eureka. Usado para aplicar un descuento a un pago.
@FeignClient(name = "promociones", configuration = FeignConfig.class, fallback = PromocionesClientFallback.class)
public interface PromocionesClient {

    @GetMapping("/api/v1/promociones/{id}")
    PromocionRemotaDTO obtenerPromocion(@PathVariable("id") int id);
}
