package com.BenditoBocado.Pagos.client;

import com.BenditoBocado.Pagos.config.FeignConfig;
import com.BenditoBocado.Pagos.dto.PedidoRemotoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

// Cliente Feign hacia el microservicio "pedidos", resuelto por nombre a
// traves de Eureka. Usado para validar el pedido antes de generar un pago,
// y para avisarle al pedido que ya tiene un pago vinculado.
@FeignClient(name = "pedidos", configuration = FeignConfig.class, fallback = PedidosClientFallback.class)
public interface PedidosClient {

    @GetMapping("/api/v1/pedidos/{id}")
    PedidoRemotoDTO obtenerPedido(@PathVariable("id") Integer id);

    @PutMapping("/api/v1/pedidos/{id}/pago/{pagoId}")
    void vincularPago(@PathVariable("id") Integer id, @PathVariable("pagoId") Integer pagoId);
}
