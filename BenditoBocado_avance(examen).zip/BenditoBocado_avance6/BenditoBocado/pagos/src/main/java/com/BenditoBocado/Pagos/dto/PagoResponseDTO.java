package com.BenditoBocado.Pagos.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class PagoResponseDTO {

    private int id;
    private String numeroMesa;
    private String mesero;
    private LocalDate fecha;
    private BigDecimal total;
    private String metodoPago;
    private String estado;

    public PagoResponseDTO() {
    }

    public PagoResponseDTO(int id, String numeroMesa, String mesero, LocalDate fecha,
                          BigDecimal total, String metodoPago, String estado) {
        this.id = id;
        this.numeroMesa = numeroMesa;
        this.mesero = mesero;
        this.fecha = fecha;
        this.total = total;
        this.metodoPago = metodoPago;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNumeroMesa() {
        return numeroMesa;
    }

    public void setNumeroMesa(String numeroMesa) {
        this.numeroMesa = numeroMesa;
    }

    public String getMesero() {
        return mesero;
    }

    public void setMesero(String mesero) {
        this.mesero = mesero;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
