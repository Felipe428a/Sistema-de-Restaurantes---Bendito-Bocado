package com.BenditoBocado.Clientes.service;

import com.BenditoBocado.Clientes.client.RestaurantesClient;
import com.BenditoBocado.Clientes.dto.CalificacionRequestDTO;
import com.BenditoBocado.Clientes.dto.CalificacionResponseDTO;
import com.BenditoBocado.Clientes.dto.RestauranteRemotoDTO;
import com.BenditoBocado.Clientes.exception.ClientesNotFoundException;
import com.BenditoBocado.Clientes.model.Calificacion;
import com.BenditoBocado.Clientes.repository.CalificacionRepository;
import com.BenditoBocado.Clientes.repository.ClientesRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CalificacionServiceTest {

    @Mock
    private CalificacionRepository calificacionRepository;

    @Mock
    private ClientesRepository clientesRepository;

    @Mock
    private RestaurantesClient restaurantesClient;

    @InjectMocks
    private CalificacionService calificacionService;

    private CalificacionRequestDTO requestDTO;

    @BeforeEach
    void setUp() {
        requestDTO = new CalificacionRequestDTO();
        requestDTO.setRestauranteId(10);
        requestDTO.setPuntuacion(5);
        requestDTO.setComentario("Excelente atención");
    }

    @Test
    void agregarCalificacion_clienteNoExiste_lanzaExcepcion() {
        when(clientesRepository.existsById(1)).thenReturn(false);

        assertThrows(ClientesNotFoundException.class,
                () -> calificacionService.agregarCalificacion(1, requestDTO));
        verify(restaurantesClient, never()).obtenerRestaurante(any());
    }

    @Test
    void agregarCalificacion_restauranteNoExiste_lanzaExcepcion() {
        when(clientesRepository.existsById(1)).thenReturn(true);
        when(restaurantesClient.obtenerRestaurante(10)).thenReturn(null); // fallback / no existe

        assertThrows(IllegalStateException.class,
                () -> calificacionService.agregarCalificacion(1, requestDTO));
        verify(calificacionRepository, never()).save(any());
    }

    @Test
    void agregarCalificacion_datosValidos_seGuardaYEnriqueceConNombreDelRestaurante() {
        when(clientesRepository.existsById(1)).thenReturn(true);
        RestauranteRemotoDTO restaurante = new RestauranteRemotoDTO();
        restaurante.setId(10);
        restaurante.setNombre("Cocinerias Doña Rosa");
        when(restaurantesClient.obtenerRestaurante(10)).thenReturn(restaurante);

        Calificacion guardada = new Calificacion();
        guardada.setId(1);
        guardada.setClienteId(1);
        guardada.setRestauranteId(10);
        guardada.setPuntuacion(5);
        guardada.setComentario("Excelente atención");
        when(calificacionRepository.save(any(Calificacion.class))).thenReturn(guardada);

        CalificacionResponseDTO resultado = calificacionService.agregarCalificacion(1, requestDTO);

        assertNotNull(resultado);
        assertEquals("Cocinerias Doña Rosa", resultado.getRestauranteNombre());
        assertEquals(5, resultado.getPuntuacion());
    }

    @Test
    void listarPorCliente_deberiaRetornarCalificacionesConNombreDeRestaurante() {
        Calificacion calificacion = new Calificacion();
        calificacion.setId(1);
        calificacion.setClienteId(1);
        calificacion.setRestauranteId(10);
        calificacion.setPuntuacion(4);
        when(calificacionRepository.findByClienteId(1)).thenReturn(List.of(calificacion));

        RestauranteRemotoDTO restaurante = new RestauranteRemotoDTO();
        restaurante.setId(10);
        restaurante.setNombre("Cocinerias Doña Rosa");
        when(restaurantesClient.obtenerRestaurante(10)).thenReturn(restaurante);

        List<CalificacionResponseDTO> resultado = calificacionService.listarPorCliente(1);

        assertEquals(1, resultado.size());
        assertEquals("Cocinerias Doña Rosa", resultado.get(0).getRestauranteNombre());
    }

    @Test
    void listarPorCliente_restauranteNoResponde_nombreQuedaNull() {
        Calificacion calificacion = new Calificacion();
        calificacion.setId(1);
        calificacion.setClienteId(1);
        calificacion.setRestauranteId(10);
        when(calificacionRepository.findByClienteId(1)).thenReturn(List.of(calificacion));
        when(restaurantesClient.obtenerRestaurante(10)).thenReturn(null);

        List<CalificacionResponseDTO> resultado = calificacionService.listarPorCliente(1);

        assertNull(resultado.get(0).getRestauranteNombre());
    }
}
