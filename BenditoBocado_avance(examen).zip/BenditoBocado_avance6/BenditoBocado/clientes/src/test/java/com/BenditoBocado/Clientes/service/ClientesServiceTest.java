package com.BenditoBocado.Clientes.service;

import com.BenditoBocado.Clientes.dto.ClientesRequestDTO;
import com.BenditoBocado.Clientes.exception.ClientesNotFoundException;
import com.BenditoBocado.Clientes.model.Clientes;
import com.BenditoBocado.Clientes.repository.ClientesRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClientesServiceTest {

    @Mock
    private ClientesRepository clientesRepository;

    @InjectMocks
    private ClientesService clientesService;

    private Clientes cliente;
    private ClientesRequestDTO requestDTO;

    @BeforeEach
    void setUp() {
        cliente = new Clientes(1, "Sofía", "Reyes", "sofia@correo.cl", "+56922222222", LocalDate.now(), true);

        requestDTO = new ClientesRequestDTO();
        requestDTO.setNombre("Sofía");
        requestDTO.setApellido("Reyes");
        requestDTO.setEmail("sofia@correo.cl");
        requestDTO.setTelefono("+56922222222");
        requestDTO.setActivo(true);
    }

    @Test
    void listarClientes_deberiaRetornarTodos() {
        when(clientesRepository.findAll()).thenReturn(List.of(cliente));

        List<Clientes> resultado = clientesService.listarClientes();

        assertEquals(1, resultado.size());
    }

    @Test
    void obtenerClientesPorId_cuandoNoExiste_lanzaExcepcion() {
        when(clientesRepository.findById(99)).thenReturn(Optional.empty());

        assertThrows(ClientesNotFoundException.class, () -> clientesService.obtenerClientesPorId(99));
    }

    @Test
    void agregarClientes_deberiaGuardarYRetornarCliente() {
        when(clientesRepository.save(any(Clientes.class))).thenReturn(cliente);

        Clientes resultado = clientesService.agregarClientes(requestDTO);

        assertNotNull(resultado);
        assertEquals("Sofía", resultado.getNombre());
    }

    @Test
    void actualizarClientes_cuandoExiste_deberiaActualizarDatos() {
        when(clientesRepository.findById(1)).thenReturn(Optional.of(cliente));
        when(clientesRepository.save(any(Clientes.class))).thenReturn(cliente);

        requestDTO.setNombre("Sofía Actualizada");
        Clientes resultado = clientesService.actualizarClientes(1, requestDTO);

        assertEquals("Sofía Actualizada", resultado.getNombre());
    }

    @Test
    void eliminarCliente_cuandoExiste_deberiaEliminarlo() {
        when(clientesRepository.findById(1)).thenReturn(Optional.of(cliente));

        clientesService.eliminarCliente(1);

        verify(clientesRepository).delete(cliente);
    }
}
