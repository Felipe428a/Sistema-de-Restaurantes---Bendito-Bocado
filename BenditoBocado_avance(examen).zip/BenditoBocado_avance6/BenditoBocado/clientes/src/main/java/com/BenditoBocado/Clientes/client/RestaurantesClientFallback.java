package com.BenditoBocado.Clientes.client;

import com.BenditoBocado.Clientes.dto.RestauranteRemotoDTO;
import org.springframework.stereotype.Component;

@Component
public class RestaurantesClientFallback implements RestaurantesClient {

    @Override
    public RestauranteRemotoDTO obtenerRestaurante(Integer id) {
        return null;
    }
}
