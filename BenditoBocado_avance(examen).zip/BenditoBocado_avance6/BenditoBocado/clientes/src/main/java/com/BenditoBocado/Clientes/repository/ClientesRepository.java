package com.BenditoBocado.Clientes.repository;

import com.BenditoBocado.Clientes.model.Clientes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientesRepository extends JpaRepository<Clientes, Integer> {
}
