package com.BenditoBocado.Clientes.repository;

import com.BenditoBocado.Clientes.model.Calificacion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CalificacionRepository extends JpaRepository<Calificacion, Integer> {
    List<Calificacion> findByClienteId(Integer clienteId);
    List<Calificacion> findByRestauranteId(Integer restauranteId);
}
