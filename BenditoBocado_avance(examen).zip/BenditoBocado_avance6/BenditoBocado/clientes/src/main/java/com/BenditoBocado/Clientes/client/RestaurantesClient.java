package com.BenditoBocado.Clientes.client;

import com.BenditoBocado.Clientes.config.FeignConfig;
import com.BenditoBocado.Clientes.dto.RestauranteRemotoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// Cliente Feign hacia el microservicio "restaurantes", resuelto por nombre
// a traves de Eureka. Usado para validar que el restaurante exista antes
// de registrar una calificacion/reseña de un cliente.
@FeignClient(name = "restaurantes", configuration = FeignConfig.class, fallback = RestaurantesClientFallback.class)
public interface RestaurantesClient {

    @GetMapping("/api/v1/restaurantes/{id}")
    RestauranteRemotoDTO obtenerRestaurante(@PathVariable("id") Integer id);
}
