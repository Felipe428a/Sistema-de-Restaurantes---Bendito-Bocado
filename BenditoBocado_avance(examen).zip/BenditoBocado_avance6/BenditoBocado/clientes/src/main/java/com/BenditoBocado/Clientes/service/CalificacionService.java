package com.BenditoBocado.Clientes.service;

import com.BenditoBocado.Clientes.client.RestaurantesClient;
import com.BenditoBocado.Clientes.dto.CalificacionRequestDTO;
import com.BenditoBocado.Clientes.dto.CalificacionResponseDTO;
import com.BenditoBocado.Clientes.dto.RestauranteRemotoDTO;
import com.BenditoBocado.Clientes.exception.ClientesNotFoundException;
import com.BenditoBocado.Clientes.model.Calificacion;
import com.BenditoBocado.Clientes.repository.CalificacionRepository;
import com.BenditoBocado.Clientes.repository.ClientesRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CalificacionService {

    private final CalificacionRepository calificacionRepository;
    private final ClientesRepository clientesRepository;
    private final RestaurantesClient restaurantesClient;

    public CalificacionService(CalificacionRepository calificacionRepository,
                                ClientesRepository clientesRepository,
                                RestaurantesClient restaurantesClient) {
        this.calificacionRepository = calificacionRepository;
        this.clientesRepository = clientesRepository;
        this.restaurantesClient = restaurantesClient;
    }

    // Clientes <-> Restaurantes: valida contra "restaurantes" (via Feign) que
    // el restaurante exista antes de registrar la calificacion/reseña.
    public CalificacionResponseDTO agregarCalificacion(Integer clienteId, CalificacionRequestDTO dto) {
        if (!clientesRepository.existsById(clienteId)) {
            throw new ClientesNotFoundException("Cliente no encontrado con id " + clienteId);
        }

        RestauranteRemotoDTO restaurante = restaurantesClient.obtenerRestaurante(dto.getRestauranteId());
        if (restaurante == null) {
            throw new IllegalStateException(
                    "No se pudo validar el restaurante " + dto.getRestauranteId() +
                            " (servicio restaurantes no disponible o restaurante inexistente)");
        }

        Calificacion calificacion = new Calificacion();
        calificacion.setClienteId(clienteId);
        calificacion.setRestauranteId(dto.getRestauranteId());
        calificacion.setPuntuacion(dto.getPuntuacion());
        calificacion.setComentario(dto.getComentario());
        calificacion.setFecha(LocalDate.now());

        Calificacion guardada = calificacionRepository.save(calificacion);
        return CalificacionResponseDTO.fromEntity(guardada, restaurante.getNombre());
    }

    public List<CalificacionResponseDTO> listarPorCliente(Integer clienteId) {
        return calificacionRepository.findByClienteId(clienteId).stream()
                .map(c -> {
                    RestauranteRemotoDTO restaurante = restaurantesClient.obtenerRestaurante(c.getRestauranteId());
                    return CalificacionResponseDTO.fromEntity(c, restaurante != null ? restaurante.getNombre() : null);
                })
                .collect(Collectors.toList());
    }
}
