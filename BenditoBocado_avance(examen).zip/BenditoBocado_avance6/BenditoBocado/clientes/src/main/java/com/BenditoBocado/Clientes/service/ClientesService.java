package com.BenditoBocado.Clientes.service;

import com.BenditoBocado.Clientes.dto.ClientesRequestDTO;
import com.BenditoBocado.Clientes.exception.ClientesNotFoundException;
import com.BenditoBocado.Clientes.model.Clientes;
import com.BenditoBocado.Clientes.repository.ClientesRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ClientesService {

    private final ClientesRepository clientesRepository;

    public ClientesService(ClientesRepository clientesRepository) {
        this.clientesRepository = clientesRepository;
    }

    public List<Clientes> listarClientes() {
        return clientesRepository.findAll();
    }

    public Clientes obtenerClientesPorId(int id) {
        return clientesRepository.findById(id)
                .orElseThrow(() -> new ClientesNotFoundException("Cliente no encontrado con id " + id));
    }

    public Clientes agregarClientes(ClientesRequestDTO clientesDTO) {
        Clientes clientes = new Clientes();
        clientes.setNombre(clientesDTO.getNombre());
        clientes.setApellido(clientesDTO.getApellido());
        clientes.setEmail(clientesDTO.getEmail());
        clientes.setTelefono(clientesDTO.getTelefono());
        clientes.setFechaRegistro(LocalDate.now());
        clientes.setActivo(clientesDTO.isActivo());
        return clientesRepository.save(clientes);
    }

    public Clientes actualizarClientes(int id, ClientesRequestDTO clientesDTO) {
        Clientes clientesExistente = obtenerClientesPorId(id);
        clientesExistente.setNombre(clientesDTO.getNombre());
        clientesExistente.setApellido(clientesDTO.getApellido());
        clientesExistente.setEmail(clientesDTO.getEmail());
        clientesExistente.setTelefono(clientesDTO.getTelefono());
        clientesExistente.setActivo(clientesDTO.isActivo());
        return clientesRepository.save(clientesExistente);
    }

    public void eliminarCliente(int id) {
        Clientes clientesExistente = obtenerClientesPorId(id);
        clientesRepository.delete(clientesExistente);
    }
}
