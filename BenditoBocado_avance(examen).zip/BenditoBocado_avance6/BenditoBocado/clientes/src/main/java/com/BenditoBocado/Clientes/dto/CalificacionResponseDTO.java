package com.BenditoBocado.Clientes.dto;

import com.BenditoBocado.Clientes.model.Calificacion;

import java.time.LocalDate;

public class CalificacionResponseDTO {

    private Integer id;
    private Integer clienteId;
    private Integer restauranteId;
    private String restauranteNombre; // enriquecido via Feign a "restaurantes"; null si el servicio no respondió
    private int puntuacion;
    private String comentario;
    private LocalDate fecha;

    public CalificacionResponseDTO() {
    }

    public static CalificacionResponseDTO fromEntity(Calificacion c, String restauranteNombre) {
        CalificacionResponseDTO dto = new CalificacionResponseDTO();
        dto.id = c.getId();
        dto.clienteId = c.getClienteId();
        dto.restauranteId = c.getRestauranteId();
        dto.restauranteNombre = restauranteNombre;
        dto.puntuacion = c.getPuntuacion();
        dto.comentario = c.getComentario();
        dto.fecha = c.getFecha();
        return dto;
    }

    public Integer getId() { return id; }
    public Integer getClienteId() { return clienteId; }
    public Integer getRestauranteId() { return restauranteId; }
    public String getRestauranteNombre() { return restauranteNombre; }
    public int getPuntuacion() { return puntuacion; }
    public String getComentario() { return comentario; }
    public LocalDate getFecha() { return fecha; }
}
