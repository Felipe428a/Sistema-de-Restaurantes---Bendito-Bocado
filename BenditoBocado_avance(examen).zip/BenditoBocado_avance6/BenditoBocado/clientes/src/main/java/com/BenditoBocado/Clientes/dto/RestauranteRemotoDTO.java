package com.BenditoBocado.Clientes.dto;

// Representa el Restaurante del microservicio "restaurantes", tal como lo
// consume "clientes" via Feign para validar que exista antes de calificarlo.
public class RestauranteRemotoDTO {
    private Integer id;
    private String nombre;
    private String estado;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
