package com.BenditoBocado.Clientes.exception;

public class ClientesNotFoundException extends RuntimeException {

    public ClientesNotFoundException(String mensaje) {
        super(mensaje);
    }

    public ClientesNotFoundException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}