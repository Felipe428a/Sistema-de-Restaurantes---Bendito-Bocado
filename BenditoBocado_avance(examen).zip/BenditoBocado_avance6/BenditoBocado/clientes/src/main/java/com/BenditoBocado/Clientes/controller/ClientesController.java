package com.BenditoBocado.Clientes.controller;

import com.BenditoBocado.Clientes.dto.CalificacionRequestDTO;
import com.BenditoBocado.Clientes.dto.CalificacionResponseDTO;
import com.BenditoBocado.Clientes.dto.ClientesRequestDTO;
import com.BenditoBocado.Clientes.model.Clientes;
import com.BenditoBocado.Clientes.service.CalificacionService;
import com.BenditoBocado.Clientes.service.ClientesService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/clientes")
@CrossOrigin(origins = "*")
public class ClientesController {

    private final ClientesService clientesService;
    private final CalificacionService calificacionService;

    public ClientesController(ClientesService clientesService, CalificacionService calificacionService) {
        this.clientesService = clientesService;
        this.calificacionService = calificacionService;
    }

    @GetMapping
    public ResponseEntity<List<Clientes>> obtenerClientes() {
        return ResponseEntity.ok(clientesService.listarClientes());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Clientes> obtenerClientesPorId(@PathVariable int id) {
        return ResponseEntity.ok(clientesService.obtenerClientesPorId(id));
    }

    @PostMapping
    public ResponseEntity<Clientes> crearClientes(@Valid @RequestBody ClientesRequestDTO clientesDTO) {
        Clientes nuevoClientes = clientesService.agregarClientes(clientesDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoClientes);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Clientes> actualizarClientes(@PathVariable int id,
                                                     @Valid @RequestBody ClientesRequestDTO clientesDTO) {
        return ResponseEntity.ok(clientesService.actualizarClientes(id, clientesDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarClientes(@PathVariable int id) {
        clientesService.eliminarCliente(id);
        return ResponseEntity.noContent().build();
    }

    // Clientes <-> Restaurantes: un cliente califica/reseña un restaurante.
    @PostMapping("/{clienteId}/calificaciones")
    public ResponseEntity<CalificacionResponseDTO> calificarRestaurante(
            @PathVariable Integer clienteId,
            @Valid @RequestBody CalificacionRequestDTO calificacionDTO) {
        CalificacionResponseDTO creada = calificacionService.agregarCalificacion(clienteId, calificacionDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(creada);
    }

    @GetMapping("/{clienteId}/calificaciones")
    public ResponseEntity<List<CalificacionResponseDTO>> obtenerCalificaciones(@PathVariable Integer clienteId) {
        return ResponseEntity.ok(calificacionService.listarPorCliente(clienteId));
    }
}
