package com.BenditoBocado.Clientes.model;

import jakarta.persistence.*;
import java.time.LocalDate;

// Clientes <-> Restaurantes: un cliente califica/reseña un restaurante.
// "restauranteId" es una FK logica hacia el microservicio "restaurantes"
// (no hay @ManyToOne porque cada microservicio tiene su propia base de datos).
@Entity
@Table(name = "calificaciones")
public class Calificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "cliente_id", nullable = false)
    private Integer clienteId;

    @Column(name = "restaurante_id", nullable = false)
    private Integer restauranteId;

    @Column(nullable = false)
    private int puntuacion;

    private String comentario;

    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    public Calificacion() {
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getClienteId() { return clienteId; }
    public void setClienteId(Integer clienteId) { this.clienteId = clienteId; }

    public Integer getRestauranteId() { return restauranteId; }
    public void setRestauranteId(Integer restauranteId) { this.restauranteId = restauranteId; }

    public int getPuntuacion() { return puntuacion; }
    public void setPuntuacion(int puntuacion) { this.puntuacion = puntuacion; }

    public String getComentario() { return comentario; }
    public void setComentario(String comentario) { this.comentario = comentario; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
}
