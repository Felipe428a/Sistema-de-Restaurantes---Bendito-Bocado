package com.BenditoBocado.Direcciones.dto;

import jakarta.validation.constraints.NotBlank;

public class DireccionRequestDTO {

  @NotBlank(message = "La calle es obligatoria")
  private String calle;

  @NotBlank(message = "El número es obligatorio")
  private String numero;

  @NotBlank(message = "La ciudad es obligatoria")
  private String ciudad;

  @NotBlank(message = "La región es obligatoria")
  private String region;

  @NotBlank(message = "El código postal es obligatorio")
  private String codigoPostal;

  public String getCalle() {
    return calle;
  }

  public void setCalle(String calle) {
    this.calle = calle;
  }

  public String getNumero() {
    return numero;
  }

  public void setNumero(String numero) {
    this.numero = numero;
  }

  public String getCiudad() {
    return ciudad;
  }

  public void setCiudad(String ciudad) {
    this.ciudad = ciudad;
  }

  public String getRegion() {
    return region;
  }

  public void setRegion(String region) {
    this.region = region;
  }

  public String getCodigoPostal() {
    return codigoPostal;
  }

  public void setCodigoPostal(String codigoPostal) {
    this.codigoPostal = codigoPostal;
  }
}
