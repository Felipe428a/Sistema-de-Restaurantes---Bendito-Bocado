package com.BenditoBocado.Direcciones.controller;

import com.BenditoBocado.Direcciones.dto.DireccionRequestDTO;
import com.BenditoBocado.Direcciones.model.Direccion;
import com.BenditoBocado.Direcciones.service.DireccionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/direcciones")
public class DireccionController {

  private final DireccionService direccionService;

  public DireccionController(DireccionService direccionService) {
    this.direccionService = direccionService;
  }

  @GetMapping
  public ResponseEntity<List<Direccion>> obtenerDirecciones() {
    return ResponseEntity.ok(direccionService.listarDirecciones());
  }

  @GetMapping("/{id}")
  public ResponseEntity<Direccion> obtenerDireccion(@PathVariable int id) {
    return direccionService.buscarPorId(id)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.notFound().build());
  }

  @PostMapping
  public ResponseEntity<Direccion> crearDireccion(@Valid @RequestBody DireccionRequestDTO request) {
    Direccion direccion = new Direccion();
    direccion.setCalle(request.getCalle());
    direccion.setNumero(request.getNumero());
    direccion.setCiudad(request.getCiudad());
    direccion.setRegion(request.getRegion());
    direccion.setCodigoPostal(request.getCodigoPostal());

    Direccion nueva = direccionService.agregarDireccion(direccion);
    return ResponseEntity.status(HttpStatus.CREATED).body(nueva);
  }
}
