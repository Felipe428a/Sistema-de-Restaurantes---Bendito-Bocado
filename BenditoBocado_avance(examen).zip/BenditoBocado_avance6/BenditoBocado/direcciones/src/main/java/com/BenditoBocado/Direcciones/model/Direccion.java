package com.BenditoBocado.Direcciones.model;

import jakarta.persistence.*;

@Entity
@Table(name = "direcciones")
public class Direccion {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;

  @Column(nullable = false)
  private String calle;

  @Column(nullable = false)
  private String numero;

  @Column(nullable = false)
  private String ciudad;

  @Column(nullable = false)
  private String region;

  @Column(nullable = false)
  private String codigoPostal;


  public Direccion() {
  }

  public Direccion(int id, String calle, String numero, String ciudad, String region,
                   String codigoPostal) {
    this.id = id;
    this.calle = calle;
    this.numero = numero;
    this.ciudad = ciudad;
    this.region = region;
    this.codigoPostal = codigoPostal;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getCalle() {
    return calle;
  }

  public void setCalle(String calle) {
    this.calle = calle;
  }

  public String getNumero() {
    return numero;
  }

  public void setNumero(String numero) {
    this.numero = numero;
  }

  public String getCiudad() {
    return ciudad;
  }

  public void setCiudad(String ciudad) {
    this.ciudad = ciudad;
  }

  public String getRegion() {
    return region;
  }

  public void setRegion(String region) {
    this.region = region;
  }

  public String getCodigoPostal() {
    return codigoPostal;
  }

  public void setCodigoPostal(String codigoPostal) {
    this.codigoPostal = codigoPostal;
  }

  public String getTipo() {
    return null;
  }

  public void setTipo(String tipo) {
    // removed field; kept method to avoid compilation errors if referenced elsewhere
  }

  public boolean isActivo() {
    // removed field; default false
    return false;
  }

  public void setActivo(boolean activo) {
    // removed field
  }
}
