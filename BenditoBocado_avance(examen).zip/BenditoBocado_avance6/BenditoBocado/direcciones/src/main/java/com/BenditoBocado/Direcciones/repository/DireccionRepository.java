package com.BenditoBocado.Direcciones.repository;

import com.BenditoBocado.Direcciones.model.Direccion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DireccionRepository extends JpaRepository<Direccion, Integer> {

}
