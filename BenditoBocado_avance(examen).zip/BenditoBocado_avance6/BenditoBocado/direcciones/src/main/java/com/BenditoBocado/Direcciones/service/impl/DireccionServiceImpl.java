package com.BenditoBocado.Direcciones.service.impl;

import com.BenditoBocado.Direcciones.model.Direccion;
import com.BenditoBocado.Direcciones.repository.DireccionRepository;
import com.BenditoBocado.Direcciones.service.DireccionService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DireccionServiceImpl implements DireccionService {

  private final DireccionRepository direccionRepository;

  public DireccionServiceImpl(DireccionRepository direccionRepository) {
    this.direccionRepository = direccionRepository;
  }

  @Override
  public List<Direccion> listarDirecciones() {
    return direccionRepository.findAll();
  }

  @Override
  public Direccion agregarDireccion(Direccion direccion) {
    return direccionRepository.save(direccion);
  }

  @Override
  public Optional<Direccion> buscarPorId(int id) {
    return direccionRepository.findById(id);
  }
}
