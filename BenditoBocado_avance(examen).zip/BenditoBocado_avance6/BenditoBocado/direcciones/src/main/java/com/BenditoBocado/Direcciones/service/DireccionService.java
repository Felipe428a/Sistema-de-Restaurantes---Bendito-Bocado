package com.BenditoBocado.Direcciones.service;

import com.BenditoBocado.Direcciones.model.Direccion;

import java.util.List;
import java.util.Optional;

public interface DireccionService {
  List<Direccion> listarDirecciones();

  Direccion agregarDireccion(Direccion direccion);

  // Usado por "repartidores" (via Feign) para validar la direccion asignada.
  Optional<Direccion> buscarPorId(int id);
}
