package com.BenditoBocado.Direcciones.service.impl;

import com.BenditoBocado.Direcciones.model.Direccion;
import com.BenditoBocado.Direcciones.repository.DireccionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DireccionServiceImplTest {

    @Mock
    private DireccionRepository direccionRepository;

    @InjectMocks
    private DireccionServiceImpl direccionService;

    private Direccion direccion;

    @BeforeEach
    void setUp() {
        direccion = new Direccion(1, "Av. Siempre Viva", "742", "Valparaíso", "Valparaíso", "2340000");
    }

    @Test
    void listarDirecciones_deberiaRetornarTodas() {
        when(direccionRepository.findAll()).thenReturn(List.of(direccion));

        List<Direccion> resultado = direccionService.listarDirecciones();

        assertEquals(1, resultado.size());
    }

    @Test
    void agregarDireccion_deberiaGuardarYRetornar() {
        when(direccionRepository.save(any(Direccion.class))).thenReturn(direccion);

        Direccion resultado = direccionService.agregarDireccion(direccion);

        assertNotNull(resultado);
        assertEquals("Av. Siempre Viva", resultado.getCalle());
    }

    @Test
    void buscarPorId_cuandoExiste_deberiaRetornarla() {
        when(direccionRepository.findById(1)).thenReturn(Optional.of(direccion));

        Optional<Direccion> resultado = direccionService.buscarPorId(1);

        assertTrue(resultado.isPresent());
        assertEquals("Valparaíso", resultado.get().getCiudad());
    }

    @Test
    void buscarPorId_cuandoNoExiste_deberiaRetornarEmpty() {
        when(direccionRepository.findById(99)).thenReturn(Optional.empty());

        Optional<Direccion> resultado = direccionService.buscarPorId(99);

        assertTrue(resultado.isEmpty());
    }
}
