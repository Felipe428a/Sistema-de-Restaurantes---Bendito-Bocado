package com.BenditoBocado.categorias.service;

import com.BenditoBocado.categorias.model.Categoria;
import com.BenditoBocado.categorias.repository.CategoriaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;

    public CategoriaService(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    public List<Categoria> listarCategorias() {
        return categoriaRepository.findAll();
    }

    public Categoria agregarCategoria(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }

    public boolean datosValidos(Categoria categoria) {
        if (categoria.getNombre() == null || categoria.getNombre().isBlank()) {
            return false;
        }
        if (categoria.getTipo() == null || categoria.getTipo().isBlank()) {
            return false;
        }
        if (categoria.getDescripcion() == null || categoria.getDescripcion().isBlank()) {
            return false;
        }
        if (categoria.getOrigen() == null || categoria.getOrigen().isBlank()) {
            return false;
        }
        if (categoria.getEstado() == null || categoria.getEstado().isBlank()) {
            return false;
        }
        return categoria.getPlatosDisponibles() >= 0;
    }
}
