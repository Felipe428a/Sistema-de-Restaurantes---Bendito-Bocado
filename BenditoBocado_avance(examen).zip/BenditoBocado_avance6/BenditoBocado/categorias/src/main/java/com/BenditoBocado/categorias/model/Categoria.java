package com.BenditoBocado.categorias.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;

@Entity
@Table(name = "categorias")
@Schema(name = "Categoria", description = "Entidad que representa una categoría")
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador", example = "1")
    private int id;

    @Column(nullable = false)
    @Schema(description = "Nombre de la categoría", example = "Salsas picantes")
    private String nombre;

    @Column(nullable = false)
    @Schema(description = "Tipo de la categoría", example = "Acompañamiento")
    private String tipo;

    @Column(nullable = false)
    @Schema(description = "Descripción de la categoría")
    private String descripcion;

    @Column(nullable = false)
    @Schema(description = "Origen de la categoría")
    private String origen;

    @Column(nullable = false)
    @Schema(description = "Estado de la categoría", example = "ACTIVO")
    private String estado;

    @Column(nullable = false)
    @Schema(description = "Platos disponibles en la categoría", example = "0")
    private int platosDisponibles;

    public Categoria() {
    }

    public Categoria(int id, String nombre, String tipo, String descripcion,
                     String origen, String estado, int platosDisponibles) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.origen = origen;
        this.estado = estado;
        this.platosDisponibles = platosDisponibles;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getPlatosDisponibles() {
        return platosDisponibles;
    }

    public void setPlatosDisponibles(int platosDisponibles) {
        this.platosDisponibles = platosDisponibles;
    }
}
