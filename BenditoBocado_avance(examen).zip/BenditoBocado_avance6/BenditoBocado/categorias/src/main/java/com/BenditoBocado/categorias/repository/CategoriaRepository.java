package com.BenditoBocado.categorias.repository;

import com.BenditoBocado.categorias.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
}
