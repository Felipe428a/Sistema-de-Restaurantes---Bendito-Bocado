package com.BenditoBocado.categorias.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

@Schema(name = "CategoriaRequestDTO", description = "DTO para crear/actualizar una categoría")
public class CategoriaRequestDTO {

    @Schema(description = "Nombre de la categoría", example = "Salsas picantes")
    @NotBlank(message = "El nombre de la categoría es obligatorio")
    private String nombre;

    @Schema(description = "Tipo de categoría", example = "Acompañamiento")
    @NotBlank(message = "El tipo de categoría es obligatorio")
    private String tipo;

    @Schema(description = "Descripción de la categoría", example = "Salsas para carnes y verduras")
    @NotBlank(message = "La descripción de la categoría es obligatoria")
    private String descripcion;

    @Schema(description = "Origen de la categoría", example = "Mexico")
    @NotBlank(message = "El origen de la categoría es obligatorio")
    private String origen;

    @Schema(description = "Estado de la categoría", example = "ACTIVO")
    @NotBlank(message = "El estado de la categoría es obligatorio")
    private String estado;

    @Schema(description = "Platos disponibles en esta categoría", example = "0")
    @Min(value = 0, message = "Los platos disponibles deben ser mayor o igual a cero")
    private int platosDisponibles;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getPlatosDisponibles() {
        return platosDisponibles;
    }

    public void setPlatosDisponibles(int platosDisponibles) {
        this.platosDisponibles = platosDisponibles;
    }
}
