package com.BenditoBocado.categorias.controller;

import com.BenditoBocado.categorias.dto.CategoriaRequestDTO;
import com.BenditoBocado.categorias.model.Categoria;
import com.BenditoBocado.categorias.service.CategoriaService;
import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@CrossOrigin(origins = "*")
@Tag(name = "Categorías", description = "Operaciones sobre categorías")
@RequestMapping(value = "/api/v1/categorias", produces = MediaType.APPLICATION_JSON_VALUE)
public class CategoriaController {

    private final CategoriaService categoriaService;

    public CategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @Operation(summary = "Listar categorías", description = "Devuelve la lista de categorías con enlaces HATEOAS")
    @ApiResponse(responseCode = "200", description = "Lista devuelta", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Categoria.class)))
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CollectionModel<EntityModel<Categoria>>> obtenerCategorias() {
        List<Categoria> categorias = categoriaService.listarCategorias();
        List<EntityModel<Categoria>> modelos = categorias.stream()
                .map(c -> EntityModel.of(c,
                        linkTo(methodOn(CategoriaController.class).obtenerCategorias()).withRel("categorias"),
                        linkTo(methodOn(CategoriaController.class).obtenerCategorias()).withSelfRel()))
                .collect(Collectors.toList());

        CollectionModel<EntityModel<Categoria>> collection = CollectionModel.of(modelos,
                linkTo(methodOn(CategoriaController.class).obtenerCategorias()).withSelfRel());
        return ResponseEntity.ok(collection);
    }

    @Operation(summary = "Crear categoría", description = "Crea una categoría y devuelve la representación con enlaces HATEOAS")
    @ApiResponse(responseCode = "201", description = "Categoría creada", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Categoria.class)))
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<EntityModel<Categoria>> crearCategoria(@Parameter(description = "Datos de la categoría a crear") @Valid @RequestBody CategoriaRequestDTO categoriaDTO) {
        Categoria categoria = new Categoria();
        categoria.setNombre(categoriaDTO.getNombre());
        categoria.setTipo(categoriaDTO.getTipo());
        categoria.setDescripcion(categoriaDTO.getDescripcion());
        categoria.setOrigen(categoriaDTO.getOrigen());
        categoria.setEstado(categoriaDTO.getEstado());
        categoria.setPlatosDisponibles(categoriaDTO.getPlatosDisponibles());

        Categoria nuevaCategoria = categoriaService.agregarCategoria(categoria);

        EntityModel<Categoria> entity = EntityModel.of(nuevaCategoria,
                linkTo(methodOn(CategoriaController.class).obtenerCategorias()).withRel("categorias"),
                linkTo(methodOn(CategoriaController.class).obtenerCategorias()).withSelfRel());
        return ResponseEntity.status(HttpStatus.CREATED).body(entity);
    }

    @GetMapping("/simple")
    public ResponseEntity<List<Categoria>> listarSimple() {
        return ResponseEntity.ok(categoriaService.listarCategorias());
    }
}
