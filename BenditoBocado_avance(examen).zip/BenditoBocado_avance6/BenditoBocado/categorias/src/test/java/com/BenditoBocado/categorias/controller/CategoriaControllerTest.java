package com.BenditoBocado.categorias.controller;

import com.BenditoBocado.categorias.dto.CategoriaRequestDTO;
import com.BenditoBocado.categorias.model.Categoria;
import com.BenditoBocado.categorias.service.CategoriaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CategoriaControllerTest {

    @Mock
    private CategoriaService categoriaService;

    @InjectMocks
    private CategoriaController categoriaController;

    @BeforeEach
    void setup() {
        // setup if needed
    }

    @Test
    void obtenerCategorias_givenCategorias_whenList_thenReturnsCollectionModel() {
        // Given
        Categoria c = new Categoria(1, "Nombre", "Tipo", "Desc", "Orig", "ACTIVO", 2);
        when(categoriaService.listarCategorias()).thenReturn(List.of(c));

        // When
        ResponseEntity<CollectionModel<EntityModel<Categoria>>> resp = categoriaController.obtenerCategorias();

        // Then
        assertThat(resp).isNotNull();
        assertThat(resp.getBody()).isNotNull();
        assertThat(resp.getBody().getContent()).hasSize(1);
    }

    @Test
    void crearCategoria_givenValidDTO_whenCreate_thenReturnsCreatedEntity() {
        // Given
        CategoriaRequestDTO dto = new CategoriaRequestDTO();
        dto.setNombre("Nombre");
        dto.setTipo("Tipo");
        dto.setDescripcion("Desc");
        dto.setOrigen("Orig");
        dto.setEstado("ACTIVO");
        dto.setPlatosDisponibles(1);

        Categoria saved = new Categoria(5, dto.getNombre(), dto.getTipo(), dto.getDescripcion(), dto.getOrigen(), dto.getEstado(), dto.getPlatosDisponibles());
        when(categoriaService.agregarCategoria(org.mockito.ArgumentMatchers.any(Categoria.class))).thenReturn(saved);

        // When
        ResponseEntity<EntityModel<Categoria>> resp = categoriaController.crearCategoria(dto);

        // Then
        assertThat(resp).isNotNull();
        assertThat(resp.getStatusCode().value()).isEqualTo(201);
        assertThat(resp.getBody()).isNotNull();
        assertThat(resp.getBody().getContent().getId()).isEqualTo(5);
    }
}
