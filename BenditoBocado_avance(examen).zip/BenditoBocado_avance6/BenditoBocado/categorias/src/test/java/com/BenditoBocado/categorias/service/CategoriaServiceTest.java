package com.BenditoBocado.categorias.service;

import com.BenditoBocado.categorias.model.Categoria;
import com.BenditoBocado.categorias.repository.CategoriaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Pruebas unitarias de la capa Service (CategoriaService).
 * No se usa base de datos real: CategoriaRepository se simula con Mockito.
 */
@ExtendWith(MockitoExtension.class)
class CategoriaServiceTest {

    // Simula el Repository, sin tocar la base de datos real
    @Mock
    private CategoriaRepository categoriaRepository;

    // Crea CategoriaService e inyecta automáticamente el mock anterior
    @InjectMocks
    private CategoriaService categoriaService;

    private Categoria categoriaValida;

    @BeforeEach
    void setUp() {
        categoriaValida = new Categoria(1, "Salsas picantes", "Acompañamiento",
                "Salsas para carnes y verduras", "Mexico", "ACTIVO", 5);
    }

    @Test
    void agregarCategoria_deberiaGuardarYRetornarLaCategoriaConId() {
        // Given: el repository simula que guarda y devuelve la categoría con id asignado
        when(categoriaRepository.save(any(Categoria.class))).thenReturn(categoriaValida);

        // When: se invoca el método del service que se está probando
        Categoria resultado = categoriaService.agregarCategoria(categoriaValida);

        // Then: se valida el resultado y que el repository fue invocado una vez
        assertNotNull(resultado);
        assertEquals(1, resultado.getId());
        assertEquals("Salsas picantes", resultado.getNombre());
        verify(categoriaRepository, times(1)).save(any(Categoria.class));
    }

    @Test
    void buscarPorId_cuandoLaCategoriaExiste_deberiaRetornarla() {
        // Given
        when(categoriaRepository.findById(1)).thenReturn(Optional.of(categoriaValida));

        // When
        Categoria resultado = categoriaService.buscarCategoriaPorId(1);

        // Then
        assertNotNull(resultado);
        assertEquals("Salsas picantes", resultado.getNombre());
        verify(categoriaRepository, times(1)).findById(1);
    }

    @Test
    void buscarPorId_cuandoNoExiste_deberiaRetornarNull() {
        // Given
        when(categoriaRepository.findById(99)).thenReturn(Optional.empty());

        // When
        Categoria resultado = categoriaService.buscarCategoriaPorId(99);

        // Then
        assertNull(resultado);
    }

    @Test
    void listarCategorias_deberiaRetornarTodasLasCategorias() {
        // Given
        when(categoriaRepository.findAll()).thenReturn(List.of(categoriaValida));

        // When
        List<Categoria> resultado = categoriaService.listarCategorias();

        // Then
        assertEquals(1, resultado.size());
        assertEquals("Acompañamiento", resultado.get(0).getTipo());
    }

    @Test
    void datosValidos_conNombreVacio_deberiaRetornarFalse() {
        // Given
        categoriaValida.setNombre("  ");

        // When
        boolean valido = categoriaService.datosValidos(categoriaValida);

        // Then
        assertFalse(valido);
    }

    @Test
    void datosValidos_conPlatosDisponiblesNegativo_deberiaRetornarFalse() {
        // Given
        categoriaValida.setPlatosDisponibles(-1);

        // When
        boolean valido = categoriaService.datosValidos(categoriaValida);

        // Then
        assertFalse(valido);
    }

    @Test
    void datosValidos_conTodosLosCamposCorrectos_deberiaRetornarTrue() {
        // When
        boolean valido = categoriaService.datosValidos(categoriaValida);

        // Then
        assertTrue(valido);
    }
}
