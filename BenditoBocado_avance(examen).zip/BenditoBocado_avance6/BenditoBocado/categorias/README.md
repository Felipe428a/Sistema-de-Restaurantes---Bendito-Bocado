Proyecto `categorias` — instrucciones rápidas

Requisitos:
- JDK 17
- Maven
- Docker (opcional)

Construir y ejecutar localmente:

1) Generar JAR:

```bash
mvn clean package -DskipTests
```

2) Ejecutar JAR:

```bash
java -jar target/categorias-0.0.1-SNAPSHOT.jar
```

Registro en Eureka (opcional):
- Por defecto el servicio intentará registrarse en `http://localhost:8761/eureka/`.
- Cambie la URL estableciendo la variable de entorno `EUREKA_DEFAULT_ZONE`.

Docker:

1) Construir imagen:

```bash
docker build -t categorias-service ./categorias
```

2) Ejecutar contenedor:

```bash
docker run -p 8084:8084 -e EUREKA_DEFAULT_ZONE=http://localhost:8761/eureka/ categorias-service
```

Docker Compose (levanta solo este servicio):

```bash
docker compose up --build
```

Notas:
- Para una arquitectura completa añada un Eureka Server y un API Gateway como servicios
  separados y configure `EUREKA_DEFAULT_ZONE` para apuntar al servidor Eureka.
- No suba credenciales ni secretos al repositorio; use variables de entorno.
