package com.benditobocado.authservice.service;

import com.benditobocado.authservice.dto.AuthDtos.ActualizarCuentaRequest;
import com.benditobocado.authservice.dto.AuthDtos.CrearCuentaRequest;
import com.benditobocado.authservice.dto.AuthDtos.LoginRequest;
import com.benditobocado.authservice.model.CuentaAcceso;
import com.benditobocado.authservice.repository.CuentaAccesoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CuentaAccesoServiceTest {

    @Mock
    private CuentaAccesoRepository repository;

    @InjectMocks
    private CuentaAccesoService service;

    private CuentaAcceso cuentaActiva;

    @BeforeEach
    void setUp() {
        cuentaActiva = new CuentaAcceso();
        cuentaActiva.setId(1L);
        cuentaActiva.setEmail("cliente1@benditobocado.cl");
        cuentaActiva.setPasswordHash(new BCryptPasswordEncoder().encode("cliente123"));
        cuentaActiva.setRol("CLIENTE");
        cuentaActiva.setEstado("ACTIVO");
        cuentaActiva.setFechaCreacion(LocalDateTime.now());
    }

    @Test
    void crear_conRolInvalido_lanzaExcepcion() {
        CrearCuentaRequest request = new CrearCuentaRequest("nuevo@correo.cl", "clave123", "SUPERADMIN", null);

        assertThrows(ResponseStatusException.class, () -> service.crear(request));
    }

    @Test
    void crear_conEmailYaRegistrado_lanzaExcepcion() {
        when(repository.existsByEmail("cliente1@benditobocado.cl")).thenReturn(true);
        CrearCuentaRequest request = new CrearCuentaRequest("cliente1@benditobocado.cl", "clave123", "CLIENTE", 1L);

        assertThrows(ResponseStatusException.class, () -> service.crear(request));
    }

    @Test
    void crear_datosValidos_deberiaGuardarLaCuenta() {
        when(repository.existsByEmail("nuevo@correo.cl")).thenReturn(false);
        when(repository.save(any(CuentaAcceso.class))).thenAnswer(inv -> inv.getArgument(0));
        CrearCuentaRequest request = new CrearCuentaRequest("nuevo@correo.cl", "clave123", "cliente", 5L);

        CuentaAcceso resultado = service.crear(request);

        assertEquals("CLIENTE", resultado.getRol());
        assertNotEquals("clave123", resultado.getPasswordHash()); // debe quedar hasheada
    }

    @Test
    void autenticar_credencialesCorrectas_deberiaRetornarLaCuenta() {
        when(repository.findByEmail("cliente1@benditobocado.cl")).thenReturn(Optional.of(cuentaActiva));
        LoginRequest request = new LoginRequest("cliente1@benditobocado.cl", "cliente123");

        CuentaAcceso resultado = service.autenticar(request);

        assertEquals("cliente1@benditobocado.cl", resultado.getEmail());
    }

    @Test
    void autenticar_passwordIncorrecta_lanzaExcepcion() {
        when(repository.findByEmail("cliente1@benditobocado.cl")).thenReturn(Optional.of(cuentaActiva));
        LoginRequest request = new LoginRequest("cliente1@benditobocado.cl", "otraClave");

        assertThrows(ResponseStatusException.class, () -> service.autenticar(request));
    }

    @Test
    void autenticar_cuentaDesactivada_lanzaExcepcion() {
        cuentaActiva.setEstado("DESACTIVADO");
        when(repository.findByEmail("cliente1@benditobocado.cl")).thenReturn(Optional.of(cuentaActiva));
        LoginRequest request = new LoginRequest("cliente1@benditobocado.cl", "cliente123");

        assertThrows(ResponseStatusException.class, () -> service.autenticar(request));
    }

    @Test
    void buscar_cuandoNoExiste_lanzaExcepcion() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResponseStatusException.class, () -> service.buscar(99L));
    }

    @Test
    void actualizar_cambiaRol_deberiaGuardarConNuevoRol() {
        when(repository.findById(1L)).thenReturn(Optional.of(cuentaActiva));
        when(repository.save(any(CuentaAcceso.class))).thenAnswer(inv -> inv.getArgument(0));
        ActualizarCuentaRequest request = new ActualizarCuentaRequest(null, "admin", null);

        CuentaAcceso resultado = service.actualizar(1L, request);

        assertEquals("ADMIN", resultado.getRol());
    }

    @Test
    void desactivar_deberiaCambiarEstadoADesactivado() {
        when(repository.findById(1L)).thenReturn(Optional.of(cuentaActiva));
        when(repository.save(any(CuentaAcceso.class))).thenAnswer(inv -> inv.getArgument(0));

        CuentaAcceso resultado = service.desactivar(1L);

        assertEquals("DESACTIVADO", resultado.getEstado());
    }
}
