package com.benditobocado.authservice.config;

import com.benditobocado.authservice.model.CuentaAcceso;
import com.benditobocado.authservice.repository.CuentaAccesoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.time.LocalDateTime;

// Crea usuarios de prueba al arrancar auth-service, uno por cada rol, para
// que quien revise el proyecto pueda probar login/JWT sin tener que
// registrarse primero. Solo corre si la tabla esta vacia (no duplica en
// reinicios sucesivos del servicio).
@Configuration
public class CuentaAccesoDataLoader {

    @Bean
    public CommandLineRunner cargarCuentasDePrueba(CuentaAccesoRepository repository) {
        return args -> {
            if (repository.count() > 0) {
                return;
            }

            BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

            repository.save(crearCuenta(encoder, "admin@benditobocado.cl", "admin123", "ADMIN", null));
            repository.save(crearCuenta(encoder, "cliente1@benditobocado.cl", "cliente123", "CLIENTE", 1L));
            repository.save(crearCuenta(encoder, "restaurante1@benditobocado.cl", "restaurante123", "RESTAURANTE", 1L));
            repository.save(crearCuenta(encoder, "repartidor1@benditobocado.cl", "repartidor123", "REPARTIDOR", 1L));
        };
    }

    private CuentaAcceso crearCuenta(BCryptPasswordEncoder encoder, String email, String passwordPlano,
                                      String rol, Long referenciaId) {
        CuentaAcceso cuenta = new CuentaAcceso();
        cuenta.setEmail(email);
        cuenta.setPasswordHash(encoder.encode(passwordPlano));
        cuenta.setRol(rol);
        cuenta.setReferenciaId(referenciaId);
        cuenta.setEstado("ACTIVO");
        cuenta.getHistorial().add("Cuenta de prueba creada " + LocalDateTime.now());
        return cuenta;
    }
}
