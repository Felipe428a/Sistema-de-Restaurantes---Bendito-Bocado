package com.benditobocado.authservice.security;

import com.benditobocado.authservice.model.CuentaAcceso;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Emisor/validador de JWT propio (HMAC-SHA256), sin dependencias externas,
 * siguiendo el mismo patrón usado en el auth-service de eSports Arena Manager.
 */
@Service
public class JwtService {

    @Value("${jwt.secret:BenditoBocadoAuthServiceSecretKey256bits}")
    private String secret;

    @Value("${jwt.expiration-seconds:86400}")
    private long expirationSeconds;

    public String emitir(CuentaAcceso cuenta) {
        String header = base64("{\"alg\":\"HS256\",\"typ\":\"JWT\"}");
        long exp = System.currentTimeMillis() / 1000 + expirationSeconds;
        String payload = base64("{\"sub\":\"" + cuenta.getEmail() + "\",\"id\":" + cuenta.getId()
                + ",\"rol\":\"" + cuenta.getRol() + "\",\"referenciaId\":" + cuenta.getReferenciaId()
                + ",\"estado\":\"" + cuenta.getEstado() + "\",\"exp\":" + exp + "}");
        return header + "." + payload + "." + firmar(header + "." + payload);
    }

    public boolean validar(String token) {
        String[] parts = token.split("\\.");
        return parts.length == 3 && firmar(parts[0] + "." + parts[1]).equals(parts[2]);
    }

    private String base64(String value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private String firmar(String value) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException("No fue posible firmar el token", e);
        }
    }
}
