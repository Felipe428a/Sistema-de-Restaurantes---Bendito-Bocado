package com.benditobocado.authservice.repository;

import com.benditobocado.authservice.model.CuentaAcceso;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CuentaAccesoRepository extends JpaRepository<CuentaAcceso, Long> {
    Optional<CuentaAcceso> findByEmail(String email);
    boolean existsByEmail(String email);
}
