# BenditoBocado — Backend de microservicios (integrado con Eureka + API Gateway + Auth Service)

Este proyecto toma los 10 microservicios de **BenditoBocado** y les aplica el mismo
patrón de infraestructura usado en **eSports Arena Manager**: registro y descubrimiento
de servicios con **Eureka**, un **API Gateway** único como puerta de entrada, y un
**Auth Service** centralizado que emite JWT.

## Qué se hizo

1. **Normalización de los 10 microservicios existentes**
   - `restaurantes`, `stock`, `menus`, `promociones`, `categorias`, `clientes`,
     `pedidos`, `repartidores`, `direcciones`, `pagos`.
   - Se unificó la versión de Spring Boot a **3.2.5** (había una mezcla de 3.4.6,
     3.5.15 y 4.0.6 — esta última con dependencias como `spring-boot-starter-webmvc`
     y `spring-boot-starter-*-test` que no existen en Maven Central) y Java a **17**,
     igual que en eSports, para que todos compartan un BOM de Spring Cloud compatible
     (`2023.0.1`).
   - Se corrigieron artifactIds duplicados (`menus` y `pedidos` compartían el
     artifactId `Restaurantes`).
   - Cada servicio ahora tiene `spring-cloud-starter-netflix-eureka-client` y se
     registra en Eureka al iniciar (`@EnableDiscoveryClient`).
   - `spring.application.name` se normalizó a minúsculas en todos (antes mezclaba
     `Restaurantes`, `Stock`, `Pagos`... con `menus`, `categorias`, `pedidos`), para
     que coincida con las rutas del Gateway.

2. **Nuevo módulo `discovery-server`** (Eureka Server, puerto `8761`), copiado del
   patrón de eSports.

3. **Nuevo módulo `api-gateway`** (Spring Cloud Gateway, puerto `8070`), con una ruta
   por servicio (`lb://<servicio>`), igual que en eSports.

4. **Nuevo módulo `auth-service`** (puerto `8091`), adaptado del auth-service de
   eSports: JWT propio (HMAC-SHA256, sin librerías externas), cuentas con rol
   `CLIENTE`, `RESTAURANTE`, `REPARTIDOR` o `ADMIN`, endpoints de registro, login,
   validación de token y gestión de cuentas. **Es independiente de las tablas de
   dominio** (`Clientes`, `Restaurantes`, `Repartidores`); solo guarda credenciales y,
   opcionalmente, un `referenciaId` hacia la entidad de dominio correspondiente.

5. **Migración de llamadas entre servicios a OpenFeign** (antes usaban `RestTemplate`
   con URLs `localhost:puerto` fijas):
   - `menus` → `categorias`: nuevo `CategoriasClient` (`@FeignClient(name = "categorias")`).
   - `pedidos` → `menus`: nuevo `MenusClient` (`@FeignClient(name = "menus")`).
   - Ambos servicios resuelven ahora el destino por nombre vía Eureka, no por puerto
     fijo, y se eliminaron sus `RestTemplateConfig`.

6. **pom.xml padre** (`packaging=pom`) con los 13 módulos, para poder compilar todo
   con un solo comando desde la raíz.

## Arquitectura y puertos

| Servicio | Puerto | Base de datos |
|---|---|---|
| discovery-server (Eureka) | 8761 | — |
| api-gateway | 8070 | — |
| auth-service | 8091 | H2 en memoria |
| restaurantes | 8080 | MySQL `restaurantes_db` |
| stock | 8081 | MySQL `stock_db` |
| menus | 8082 | H2 en memoria |
| promociones | 8083 | MySQL `promociones_db` |
| categorias | 8084 | H2 en memoria |
| clientes | 8085 | MySQL `clientes_db` |
| pedidos | 8086 | H2 en memoria |
| repartidores | 8088 | MySQL `repartidores_db` |
| direcciones | 8089 | MySQL `direcciones_db` |
| pagos | 8090 | MySQL `pagos_db` |

Todas las rutas MySQL usan `root` / `EliteSlayer_245` como credenciales por defecto
(igual que en el proyecto original) contra `localhost:3306`, con
`createDatabaseIfNotExist` implícito por `ddl-auto=update` de Hibernate. Ajusta
usuario/contraseña en cada `application.properties` si tu entorno es distinto.

## Documentación Swagger / OpenAPI

Cada microservicio de negocio expone su propia documentación interactiva en:

```
http://localhost:<puerto-del-servicio>/swagger-ui.html
```

Por ejemplo, `menus` (puerto 8082): http://localhost:8082/swagger-ui.html

Además, el **API Gateway centraliza los 11 Swagger** (todos menos
`discovery-server`, que no tiene API REST propia) en un solo lugar, con un
dropdown para elegir el servicio:

```
http://localhost:8070/webjars/swagger-ui/index.html
```

`discovery-server` no tiene Swagger porque es el servidor Eureka: no expone
endpoints REST propios de negocio, solo su dashboard nativo en
http://localhost:8761.

## Levantar todo con Docker Compose

Ya no hace falta instalar MySQL ni levantar cada servicio a mano. Desde la
raíz del proyecto (donde está este README):

```bash
docker-compose up --build
```

Esto levanta, en orden:
1. `mysql` (crea automáticamente las 7 bases de datos que se necesitan, vía `mysql-init/init.sql`)
2. `discovery-server` (Eureka, 8761)
3. `api-gateway` (8070) y `auth-service` (8091)
4. Los 12 microservicios de negocio, cada uno esperando a que Eureka (y MySQL, si corresponde) estén listos

Para apagar todo conservando los datos: `docker-compose down`
Para apagar y borrar también los datos de MySQL: `docker-compose down -v`

Nota: la primera vez que ejecutas `docker-compose up --build` puede demorar
varios minutos porque cada microservicio compila su propio jar con Maven
dentro del contenedor (no depende de tener `target/` generado antes).

## Usuarios de prueba (auth-service)

Al arrancar `auth-service` por primera vez (tabla vacía), se crean automáticamente
estas 4 cuentas para que puedas probar login/JWT sin registrarte:

| Email | Password | Rol |
|---|---|---|
| admin@benditobocado.cl | admin123 | ADMIN |
| cliente1@benditobocado.cl | cliente123 | CLIENTE |
| restaurante1@benditobocado.cl | restaurante123 | RESTAURANTE |
| repartidor1@benditobocado.cl | repartidor123 | REPARTIDOR |

Login: `POST http://localhost:8091/api/v1/auth/login` con `{"email": "...", "password": "..."}`
→ devuelve el JWT que hay que mandar como `Authorization: Bearer <token>` en los
endpoints protegidos.

## Cómo ejecutar

```bash
# 1. Levantar MySQL localmente (para restaurantes, stock, promociones, clientes,
#    repartidores, direcciones y pagos)

# 2. Compilar todo desde la raíz
./mvnw clean install -DskipTests   # o mvn si no usas el wrapper

# 3. Levantar en este orden:
cd discovery-server && ../mvnw spring-boot:run   # 8761 primero
cd api-gateway && ../mvnw spring-boot:run        # 8070
cd auth-service && ../mvnw spring-boot:run       # 8091
# luego el resto de servicios, en cualquier orden
```

Con Eureka arriba (`http://localhost:8761`) puedes ver los servicios registrándose.
Todo el tráfico externo debería entrar por el Gateway (`http://localhost:8070`), que
enruta por prefijo de path, por ejemplo:

- `POST http://localhost:8070/api/v1/auth/registro`
- `POST http://localhost:8070/api/v1/auth/login`
- `GET  http://localhost:8070/api/v1/categorias`
- `GET  http://localhost:8070/api/v1/platos`
- `POST http://localhost:8070/api/v1/pedidos`

## Decisiones y limitaciones (léelas antes de entregar/usar en producción)

- **No se pudo compilar ni ejecutar `mvn`/`javac` en este entorno** (sin acceso a
  Maven Central desde el sandbox de red), así que estos cambios se hicieron y
  revisaron a mano: XML y YAML validados sintácticamente, llaves/paréntesis de Java
  balanceados, pero **no hay garantía de compilación exitosa**. Antes de entregar,
  corre `mvn clean install` localmente y revisa errores.
- El `auth-service` es autocontenido (no valida contra `Clientes`/`Restaurantes`/
  `Repartidores` al registrar una cuenta, a diferencia de eSports donde sí llama a
  `user-service`). Si quieres esa validación cruzada, se puede añadir un
  `@FeignClient` desde `auth-service` hacia cada servicio de dominio.
- Ningún microservicio valida el JWT por sí mismo (ni lo hacía eSports en sus
  servicios de dominio); el JWT se emite pero no hay filtro de autorización en el
  Gateway ni en los servicios. Si necesitas proteger endpoints, hay que añadir un
  `GatewayFilter` que valide el token contra `auth-service` antes de enrutar.
- Downgrade de Spring Boot 4.0.6/3.4.6/3.5.15 → 3.2.5 en 8 de los 10 servicios para
  garantizar compatibilidad con Spring Cloud 2023.0.1 (la misma combinación que ya
  usaba, y con la que fue probado, eSports Arena Manager).
