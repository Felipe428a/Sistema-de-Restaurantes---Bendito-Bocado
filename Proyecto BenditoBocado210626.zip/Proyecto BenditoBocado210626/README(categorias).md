# Proyecto Categorías — Microservicio Spring Boot

## Descripción general

Este proyecto implementa un microservicio **Categorías** que forma parte de una arquitectura de microservicios para la plataforma **BenditoBocado**. Sigue los conceptos de la Semana 14: API Gateway, Eureka Service Discovery y Docker.

El servicio:
- Gestiona categorías de productos/servicios
- Se registra automáticamente en Eureka Server
- Es accesible a través de API Gateway
- Se empaqueta y ejecuta en contenedores Docker

## Requisitos previos

- **JDK 17** (o superior)
- **Maven 3.6+**
- **Docker** (opcional, para ejecución en contenedores)
- **Docker Compose** (opcional, para orquestar múltiples servicios)

## Estructura del proyecto

```
categorias/
├── src/
│   ├── main/
│   │   ├── java/com/BenditoBocado/categorias/
│   │   │   ├── CategoriasApplication.java       # Clase principal con @EnableDiscoveryClient
│   │   │   ├── controller/
│   │   │   │   └── CategoriaController.java     # Endpoints REST
│   │   │   ├── dto/
│   │   │   │   └── CategoriaRequestDTO.java     # DTO para solicitudes
│   │   │   ├── model/
│   │   │   │   └── Categoria.java               # Entidad JPA
│   │   │   ├── repository/
│   │   │   │   └── CategoriaRepository.java     # Acceso a datos
│   │   │   ├── service/
│   │   │   │   └── CategoriaService.java        # Lógica de negocio
│   │   │   └── exception/
│   │   │       └── GlobalExceptionHandler.java  # Manejo de excepciones
│   │   └── resources/
│   │       ├── application.properties            # Configuración de la aplicación
│   │       ├── static/                          # Archivos estáticos
│   │       └── templates/                       # Plantillas
│   └── test/
│       └── java/com/BenditoBocado/categorias/
│           ├── CategoriasApplicationTests.java
│           └── controller/
│               └── CategoriaControllerTest.java
├── pom.xml                                      # Dependencias Maven
├── Dockerfile                                   # Imagen Docker
├── .dockerignore                                # Archivos ignorados en build Docker
├── README.md                                    # Este archivo
└── HELP.md                                      # Documentación adicional

docker-compose.yml                              # Orquestación de servicios (raíz del proyecto)
```

## Configuración y ejecución

### 1. Ejecución local (sin Docker)

**Compilar:**
```bash
mvn clean package -DskipTests
```

**Ejecutar JAR:**
```bash
java -jar categorias/target/categorias-0.0.1-SNAPSHOT.jar
```

El servicio estará disponible en `http://localhost:8084`

### 2. Ejecución con Docker Compose (recomendado)

**Levantar el contenedor:**
```bash
docker compose up --build
```

El servicio estará disponible en `http://localhost:8084`

**Detener:**
```bash
docker compose down
```

### 3. Ejecución manual con Docker

**Compilar JAR:**
```bash
mvn clean package -DskipTests
```

**Construir imagen:**
```bash
docker build -t categorias-service ./categorias
```

**Ejecutar contenedor:**
```bash
docker run -p 8084:8084 \
  -e EUREKA_DEFAULT_ZONE=http://localhost:8761/eureka/ \
  categorias-service
```

## Configuración de Eureka

El servicio se registra automáticamente en **Eureka Server** con el nombre `CATEGORIAS`.

**Configuración por defecto (application.properties):**
```properties
eureka.client.service-url.defaultZone=http://localhost:8761/eureka/
eureka.client.register-with-eureka=true
eureka.client.fetch-registry=true
```

**Cambiar servidor Eureka:**
- Establezca la variable de entorno `EUREKA_DEFAULT_ZONE`:

```bash
export EUREKA_DEFAULT_ZONE=http://eureka-server:8761/eureka/
java -jar target/categorias-0.0.1-SNAPSHOT.jar
```

O en Docker Compose:
```yaml
environment:
  - EUREKA_DEFAULT_ZONE=http://eureka-server:8761/eureka/
```

## API Gateway

Una vez el servicio se registra en Eureka, configure el **API Gateway** con una ruta hacia este servicio.

**Ejemplo en application.yml del Gateway:**
```yaml
spring:
  cloud:
    gateway:
      routes:
        - id: categorias-service
          uri: lb://CATEGORIAS
          predicates:
            - Path=/api/categorias/**
          filters:
            - StripPrefix=1
```

Con esta configuración, el cliente accede a través del Gateway:
```
GET http://localhost:8080/api/categorias/
```

La solicitud se redirige a:
```
GET http://localhost:8084/categorias/
```

## Endpoints disponibles

Asumiendo que el servicio corre en `http://localhost:8084`:

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/categorias` | Obtiene todas las categorías |
| GET | `/categorias/{id}` | Obtiene una categoría por ID |
| POST | `/categorias` | Crea una nueva categoría |
| PUT | `/categorias/{id}` | Actualiza una categoría |
| DELETE | `/categorias/{id}` | Elimina una categoría |

**Documentación Swagger/OpenAPI:**
```
http://localhost:8084/swagger-ui.html
```

## Variables de entorno

| Variable | Valor por defecto | Descripción |
|----------|-------------------|-------------|
| `EUREKA_DEFAULT_ZONE` | `http://localhost:8761/eureka/` | URL del servidor Eureka |
| `SERVER_PORT` | `8084` | Puerto en el que escucha el servicio |
| `DB_URL` | `jdbc:h2:mem:testdb` | URL de la base de datos |
| `DB_USER` | `sa` | Usuario de la base de datos |
| `DB_PASSWORD` | (vacío) | Contraseña de la base de datos |

**Nota de seguridad:** Nunca suba credenciales reales al repositorio. Use variables de entorno o archivos `.env` locales (añadidos a `.gitignore`).

## Dependencias principales

- **Spring Boot 3.4.6**
- **Spring Cloud 2023.0.6** (Netflix Eureka, Cloud Gateway)
- **Spring Data JPA** (persistencia)
- **Spring HATEOAS** (navegabilidad REST)
- **Springdoc OpenAPI 2.8.9** (Swagger/OpenAPI)
- **H2 Database** (BD en memoria para desarrollo)
- **MySQL Connector** (soporte para BD productiva)
- **JUnit 5 + Mockito** (pruebas)

Ver `pom.xml` para lista completa.

## Pruebas

**Ejecutar pruebas unitarias:**
```bash
mvn test
```

**Con cobertura:**
```bash
mvn test jacoco:report
```

## Debugging local

**Con Visual Studio Code:**
1. Instale la extensión "Debugger for Java" (Microsoft)
2. Abra el proyecto en VS Code
3. Presione `F5` para iniciar el debugger

**Con IntelliJ IDEA:**
1. Abra el proyecto
2. Haga clic en el icono de Run/Debug en `CategoriasApplication.java`

## Integración con arquitectura completa

Para una arquitectura funcional completa, necesita:

1. **Eureka Server** (puerto 8761)
   - Descarga o crea un proyecto separado con `@EnableEurekaServer`

2. **API Gateway** (puerto 8080)
   - Descarga o crea un proyecto separado con `@EnableGateway`
   - Configure rutas que apunten a `lb://CATEGORIAS` y otros servicios registrados

3. **Este servicio (Categorías)** (puerto 8084)
   - Ya listo, se registra automáticamente en Eureka

4. **Otros microservicios** (ej. Products, Orders)
   - Implementar de forma similar, cada uno con su puerto

**Ejemplo docker-compose.yml completo:**
```yaml
version: "3.9"
services:
  eureka-server:
    build: ./eureka-server
    ports:
      - "8761:8761"

  categorias-service:
    build: ./categorias
    ports:
      - "8084:8084"
    environment:
      - EUREKA_DEFAULT_ZONE=http://eureka-server:8761/eureka/
    depends_on:
      - eureka-server

  api-gateway:
    build: ./api-gateway
    ports:
      - "8080:8080"
    environment:
      - EUREKA_DEFAULT_ZONE=http://eureka-server:8761/eureka/
    depends_on:
      - eureka-server
```

## Checklist de preparación (Semana 14)

- ✅ Microservicio principal levanta sin errores críticos
- ✅ Documentación Swagger/OpenAPI disponible en `/swagger-ui.html`
- ✅ Pruebas unitarias configuradas y ejecutables
- ✅ Eureka Client habilitado y conecta con servidor
- ✅ Dockerfile y .dockerignore configurados
- ✅ Docker Compose incluido (servicio individual)
- ✅ Variables de entorno configuradas con fallback
- ✅ README con instrucciones claras
- ✅ Código comentado en puntos clave

## Errores comunes y soluciones

| Error | Causa | Solución |
|-------|-------|----------|
| `Connection refused: localhost:8761` | Eureka Server no está corriendo | Levante Eureka Server o cambie `EUREKA_DEFAULT_ZONE` |
| `Port 8084 already in use` | Otro proceso usa el puerto | Cambie `SERVER_PORT` o cierre el proceso anterior |
| `JAR not found in Docker build` | Falta ejecutar `mvn package` | Compile primero: `mvn clean package -DskipTests` |
| `YAML parse error` | Sangría incorrecta en application.yml | Verifique espacios (no tabs) en `application.properties` |

## Licencia

Este proyecto es parte del curso **DSY1103 – Desarrollo FullStack I**.

## Contacto / Soporte

Para dudas o problemas, consulte la guía oficial de la Semana 14 o los materiales del curso.

---

**Última actualización:** Junio 2026  
**Versión:** 1.0
