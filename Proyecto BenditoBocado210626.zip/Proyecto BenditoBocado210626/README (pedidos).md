# Restaurantes - Pedidos (Consumidor)

## Descripción

Esta aplicación Spring Boot implementa un servicio de pedidos para un sistema de restaurantes enfocado en el consumidor. Permite:

- Registrar pedidos.
- Consultar pedidos.
- Consumir platos disponibles desde un servicio remoto.
- Exponer endpoints REST con documentación OpenAPI/Swagger.

El backend usa Spring Boot, Spring Data JPA y una base de datos en memoria H2 para persistir pedidos.

## Tecnologías

- Java 17
- Spring Boot 3.5.15
- Spring Web
- Spring Data JPA
- Spring Boot Validation
- Spring HATEOAS
- Springdoc OpenAPI (Swagger UI)
- H2 Database
- MySQL Connector (runtime)

## Estructura principal

- `com.BenditoBocado.Restaurantes.RestaurantesApplication`
  - Entrada de la aplicación Spring Boot.

- `controller`
  - `ConsumidorController`
    - Endpoint `/api/v1/consumer/consume`: registra un pedido desde el rol consumidor.
    - Endpoint `/api/v1/consumer/pedidos`: lista todos los pedidos.
  - `PedidoController`
    - Endpoint `/api/v1/pedidos`: lista todos los pedidos.
    - Endpoint `/api/v1/pedidos/{id}`: busca un pedido por ID y añade enlaces HATEOAS.
    - Endpoint `/api/v1/pedidos`: crea un pedido.
    - Endpoint `/api/v1/pedidos/platos-disponibles`: obtiene platos desde un servicio remoto.

- `service`
  - `PedidoService`
    - Lógica para listar, buscar, guardar y validar pedidos.
    - Convierte entre `PedidoRequestDTO`, entidad `Pedido` y `PedidoResponseDTO`.
  - `MenuConsumerService`
    - Llamada remota con `RestTemplate` a una API externa para obtener platos disponibles.

- `dto`
  - `PedidoRequestDTO`
    - Datos requeridos para crear un pedido.
  - `PedidoResponseDTO`
    - Datos devueltos al cliente al consultar pedidos.
  - `PlatoDTORemoto`
    - Representa el plato consumido desde el servicio remoto.

- `model`
  - `Pedido`
    - Entidad JPA mapeada a la tabla `pedidos`.

- `repository`
  - `PedidoRepository`
    - Repositorio Spring Data JPA para CRUD de `Pedido`.

- `config`
  - `RestTemplateConfig`
    - Configura un bean `RestTemplate` para llamadas HTTP.

- `exception`
  - `GlobalExceptionHandler`
    - Manejo centralizado de validación de request bodies.

## Configuración

Propiedades principales en `src/main/resources/application.properties`:

```properties
spring.application.name=pedidos
server.port=8086

spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.username=root
spring.datasource.password=EliteSlayer_245

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true

app.menus.url=http://localhost:8082/api/v1/platos
```

> Nota: el servicio de platos remotos se consume desde `http://localhost:8082/api/v1/platos`. Ajusta esta URL si tu servicio remoto está en otra ubicación.

## Ejecución

Desde la carpeta `Restaurantes`:

```bash
./mvnw spring-boot:run
```

En Windows PowerShell:

```powershell
.
```

O compilar y ejecutar el JAR:

```bash
./mvnw clean package
java -jar target/Restaurantes-0.0.1-SNAPSHOT.jar
```

## Endpoints principales

- `POST /api/v1/consumer/consume`
  - Crea un pedido usando `PedidoRequestDTO`.

- `GET /api/v1/consumer/pedidos`
  - Lista todos los pedidos.

- `GET /api/v1/pedidos`
  - Lista todos los pedidos.

- `GET /api/v1/pedidos/{id}`
  - Busca un pedido por ID y devuelve enlaces HATEOAS.

- `POST /api/v1/pedidos`
  - Crea un pedido usando `PedidoRequestDTO`.

- `GET /api/v1/pedidos/platos-disponibles`
  - Recupera la lista de platos desde el servicio remoto.

## Ejemplo de request para crear pedido

```json
{
  "nombreCliente": "Ana",
  "platos": "Ensalada, Jugo",
  "estado": "PENDIENTE",
  "mesa": 3,
  "total": 15000.0
}
```

## Documentación Swagger

Si arranca la aplicación correctamente, la documentación OpenAPI está disponible en:

- `http://localhost:8086/swagger-ui.html`
- `http://localhost:8086/v3/api-docs`

## Notas

- La aplicación usa H2 en memoria para persistencia por defecto, por lo que los datos se pierden al reiniciar.
- El `MenuConsumerService` devuelve una lista vacía si no alcanza el servicio remoto.
- `PedidoRequestDTO` usa validaciones de Jakarta Bean Validation para garantizar que los campos obligatorios estén presentes.

## Mejoras posibles

- Agregar un servicio de autenticación/autorización.
- Cambiar la base de datos a MySQL o PostgreSQL en producción.
- Agregar pruebas unitarias e integración para los controllers y servicios.
- Mejorar el mapeo entre DTOs y entidades con MapStruct.
